package client;

import static java.lang.System.out;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import javax.naming.NamingException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import org.apache.commons.io.IOUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;
import org.jboss.resteasy.client.jaxrs.engines.ApacheHttpClient4Engine;
import org.junit.Before;
import org.junit.Test;

import entity.UserDetails;
import ws.server.ServiceInterface;

public class RestEasyClientLiveTest {

	public static final UriBuilder FULL_PATH = UriBuilder.fromPath("http://127.0.0.1:8080/ands/api");
	UserDetails morokerUserDetails = null;
	UserDetails lanyingUserDetails = null;
	ObjectMapper jsonMapper = null;

	@Before
	public void setup() throws ClassNotFoundException, IllegalAccessException, InstantiationException, NamingException {
		jsonMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		jsonMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		final SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.ENGLISH);
		jsonMapper.setDateFormat(sdf);

		try (InputStream inputStream = new RestEasyClientLiveTest().getClass()
				.getResourceAsStream("/userdetails/moroker.json")) {
			final String userdetailsAsString = String.format(IOUtils.toString(inputStream, StandardCharsets.UTF_8));
			morokerUserDetails = jsonMapper.readValue(userdetailsAsString, UserDetails.class);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Test is going to die ...", e);
		}

		try (InputStream inputStream = new RestEasyClientLiveTest().getClass()
				.getResourceAsStream("/userdetails/lanying.json")) {
			final String userdetailsAsString = String.format(IOUtils.toString(inputStream, StandardCharsets.UTF_8));
			lanyingUserDetails = jsonMapper.readValue(userdetailsAsString, UserDetails.class);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Test is going to die ...", e);
		}
	}

	@Test
	public void testListUserDetails() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserDetails(morokerUserDetails);
		response.close();
		response = proxy.addUserDetails(lanyingUserDetails);
		response.close();

		final List<UserDetails> userDetails = proxy.listUserDetails();
		out.println("testListUserDetails - " + userDetails);
	}

	@Test
	public void testGetUserDetailsByUserId() {
		final Integer userId = 8;

		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		final Response response = proxy.addUserDetails(morokerUserDetails);
		response.close();

		//final UserDetails userDetails = (UserDetails) proxy.getUserDetailsByUserId(userId);
		//out.println("testGetUserDetailsByUserId - " + userDetails);
	}

	@Test
	public void testAddUserDetails() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserDetails(morokerUserDetails);
		response.close();
		response = proxy.addUserDetails(lanyingUserDetails);

		if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
			out.println("testAddUserDetails - Failed : HTTP error code : " + response.getStatus());
		}

		response.close();
		out.println("testAddUserDetails - Response Code: " + response.getStatus());
	}

	@Test
	public void testAddUserDetailsMultiConnection() {
		final PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
		final CloseableHttpClient httpClient = HttpClients.custom().setConnectionManager(cm).build();
		final ApacheHttpClient4Engine engine = new ApacheHttpClient4Engine(httpClient);
		final ResteasyClient client = new ResteasyClientBuilder().httpEngine(engine).build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		final Response morokerResponse = proxy.addUserDetails(morokerUserDetails);
		final Response lanyingResponse = proxy.addUserDetails(lanyingUserDetails);

		if (morokerResponse.getStatus() != Response.Status.CREATED.getStatusCode()) {
			out.println("testAddUserDetailsMultiConnection - moroker UserDetails creation Failed : HTTP error code : "
					+ morokerResponse.getStatus());
		}
		if (lanyingResponse.getStatus() != Response.Status.CREATED.getStatusCode()) {
			out.println("testAddUserDetailsMultiConnection - lanying UserDetails creation Failed : HTTP error code : "
					+ lanyingResponse.getStatus());
		}

		morokerResponse.close();
		lanyingResponse.close();
		cm.close();
		out.println("testAddUserDetailsMultiConnection - Response Code: " + morokerResponse.getStatus());
	}

	@Test
	public void testDeleteUserDetails() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserDetails(lanyingUserDetails);
		response.close();
		response = proxy.deleteUserDetails(lanyingUserDetails.getUserId());

		if (response.getStatus() != Response.Status.OK.getStatusCode()) {
			out.println(response.readEntity(String.class));
			throw new RuntimeException("testDeleteUserDetails - Failed : HTTP error code : " + response.getStatus());
		}

		response.close();
		out.println("testDeleteUserDetails - Response Code: " + response.getStatus());
	}

	@Test
	public void testUpdateUserDetails() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserDetails(lanyingUserDetails);
		response.close();
		lanyingUserDetails.setMobilePhone("0416174580");
		response = proxy.updateUserDetails(lanyingUserDetails);

		if (response.getStatus() != Response.Status.OK.getStatusCode()) {
			out.println("testUpdateUserDetails - Failed : HTTP error code : " + response.getStatus());
		}

		response.close();
		out.println("testUpdateUserDetails - Response Code: " + response.getStatus());
	}
}