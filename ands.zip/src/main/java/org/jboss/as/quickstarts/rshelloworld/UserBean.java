package org.jboss.as.quickstarts.rshelloworld;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.gt;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoCursor;

/**
 * @author Moroker
 *
 */
public class UserBean {

	public String username;
	public String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String login() {
		String returnText = Constants.LOGIN_FAILURE;
		DatabaseCRUD dbDAO = null;

		try {
			dbDAO = new DatabaseCRUD();
			dbDAO.openDB();

			boolean isCollectionAvailable = dbDAO.connectDBCollection(Constants.LOGIN_COLLECTION_NAME);

			if (isCollectionAvailable) {
				Bson searchQuery = and(gt(Constants.LOGIN_COLLECTION_USER_ID_COLUMN, username),
						gt(Constants.LOGIN_COLLECTION_PASSWORD_COLUMN, password));

				MongoCursor<Document> cursor = dbDAO.searchData(searchQuery);
				if (cursor != null && cursor.hasNext()) {
					returnText = Constants.LOGIN_SUCCESS;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return returnText;
	}

	public String signUp() {
		String returnText = Constants.SIGNUP_FAILURE;
		DatabaseCRUD dbDAO = null;
		try {
			dbDAO = new DatabaseCRUD();
			dbDAO.openDB();

			boolean isCollectionAvailable = dbDAO.connectDBCollection(Constants.LOGIN_COLLECTION_NAME);

			if (isCollectionAvailable) {
				Bson insertQuery = and(gt(Constants.LOGIN_COLLECTION_USER_ID_COLUMN, username),
						gt(Constants.LOGIN_COLLECTION_PASSWORD_COLUMN, password));

				MongoCursor<Document> cursor = dbDAO.searchData(insertQuery);
				if (cursor != null && cursor.hasNext()) {
					returnText = Constants.LOGIN_SUCCESS;
				}

				Document doc = new Document(Constants.LOGIN_COLLECTION_USER_ID_COLUMN, username)
						.append(Constants.LOGIN_COLLECTION_PASSWORD_COLUMN, password);
				dbDAO.insertData(doc);

				returnText = Constants.SIGNUP_SUCCESS;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return returnText;
	}
}