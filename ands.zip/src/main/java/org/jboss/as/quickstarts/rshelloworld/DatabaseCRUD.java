package org.jboss.as.quickstarts.rshelloworld;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.WriteResult;
import com.mongodb.client.MongoCursor;

/**
 * @author Moroker
 *
 */
public class DatabaseCRUD extends DBConnectionDAO {

	public void insertData(Document document) {
		if (collection != null && document != null) {
			collection.insertOne(document);
		}
	}

	public MongoCursor<Document> searchData(Bson searchQuery) {
		if (collection == null || searchQuery == null) {
			return null;
		}
		return collection.find(searchQuery).iterator();
	}
}