package org.jboss.as.quickstarts.rshelloworld;

/**
 * @author Moroker
 *
 */
public class Constants {

	public static final String SIGNUP_FAILURE = "signupfailure";
	public static final String SIGNUP_SUCCESS = "signupsuccess";

	public static final String LOGIN_FAILURE = "failure";
	public static final String LOGIN_SUCCESS = "success";

	public static final String LOGIN_COLLECTION_NAME = "userLogin";
	public static final String LOGIN_COLLECTION_USER_ID_COLUMN = "_id";
	public static final String LOGIN_COLLECTION_PASSWORD_COLUMN = "password";

	public static final String DATABASE = "mydb";
	public static final String USERNAME = "yang";
	public static final char[] PASSWORD = "123123".toCharArray();
}
