package controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.Study;
import session.StudyHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("dashboardAction")
@SessionScoped
public class DashboardAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StudyHomeExt studyHomeExt;

	private Study study = new Study();
	private List<Study> list = null;
	private String keywordsFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public DashboardAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		study = studyHomeExt.trimInput(study);
		if (studyHomeExt.create(study) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(Study study) {
		study = studyHomeExt.trimInput(study);
		if (studyHomeExt.update(study)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(Study study) {
		if (studyHomeExt.delete(study)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (keywordsFilter.equals("")) {
			list = studyHomeExt.find(bsonFilter);
		} else {
			list = studyHomeExt.queryLikeKeywordsIns(keywordsFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		keywordsFilter = "";
		find();
	}

	public void editThis(Study study) {
		list = studyHomeExt.queryByStudy(study);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public Study getStudy() {
		return study;
	}

	public void setStudy(Study study) {
		this.study = study;
	}

	public List<Study> getList() {
		return list;
	}

	public void setList(List<Study> list) {
		this.list = list;
	}

	public String getKeywordsFilter() {
		return keywordsFilter;
	}

	public void setKeywordsFilter(String keywordsFilter) {
		this.keywordsFilter = myNullChecker.cns(keywordsFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}