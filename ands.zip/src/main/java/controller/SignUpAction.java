package controller;

import static java.lang.System.out;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.commons.validator.routines.EmailValidator;

import entity.User;
import session.UserHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("signUpAction")
@SessionScoped
public class SignUpAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private UserHomeExt userHomeExt;

	private User user = new User();
	private String repeatPassword = "";
	private String message = "";

	private MyNullChecker myNullChecker = new MyNullChecker();

	public SignUpAction() {
	}

	@PostConstruct
	private void init() {
		user = new User();
		user.setUserType("Client");
		user.setUserStatus("Inactive");
		message = "";
	}

	public void create() {
		// Validate Username
		if (user.getUsername().equals("")) {
			message = "Please enter username";
			out.println(message);
			return;
		}
		if (!EmailValidator.getInstance().isValid(user.getUsername())) {
			message = "Invalid Username";
			out.println(message);
			return;
		}

		// Validate Password
		if (user.getPassword().equals("")) {
			message = "Please enter password";
			out.println(message);
			return;
		}
		if (repeatPassword.equals("")) {
			message = "Please enter repeat password";
			out.println(message);
			return;
		}
		if (!user.getPassword().equals(repeatPassword)) {
			message = "Password must match repeat password";
			out.println(message);
			return;
		}

		// Check Username existence
		if (userHomeExt.queryByUsername(user.getUsername()) != null) {
			message = "User exists";
			out.println(message);
			return;
		}

		if (userHomeExt.create(user) != null) {
			message = "New user created.";
		} else {
			message = "Creation failed.";
		}
		out.println(message);
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = userHomeExt.trimInput(user);
	}

	public String getRepeatPassword() {
		return repeatPassword;
	}

	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = myNullChecker.cns(repeatPassword);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}
}