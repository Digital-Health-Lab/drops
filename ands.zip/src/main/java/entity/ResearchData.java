package entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "researchData", propOrder = { "_id", "studyId", "variableName", "variableSource", "value", "linkageKey",
		"measuredAt", "createdAt", "updatedAt" })
@XmlRootElement(name = "researchData")
public class ResearchData {

	private ObjectId _id;
	private Integer studyId;
	private String variableName;
	private String variableSource;
	private String value;
	private String linkageKey;
	@JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss")
	private Date measuredAt;
	private Date createdAt;
	private Date updatedAt;

	public ResearchData() {
	}

	public ResearchData(ObjectId _id, Integer studyId, String variableName, String variableSource, String value,
			String linkageKey, Date measuredAt, Date createdAt, Date updatedAt) {
		this._id = _id;
		this.studyId = studyId;
		this.variableName = variableName;
		this.variableSource = variableSource;
		this.value = value;
		this.linkageKey = linkageKey;
		this.measuredAt = measuredAt;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getStudyId() {
		return studyId;
	}

	public void setStudyId(Integer studyId) {
		this.studyId = studyId;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public String getVariableSource() {
		return variableSource;
	}

	public void setVariableSource(String variableSource) {
		this.variableSource = variableSource;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getLinkageKey() {
		return linkageKey;
	}

	public void setLinkageKey(String linkageKey) {
		this.linkageKey = linkageKey;
	}

	public Date getMeasuredAt() {
		return measuredAt;
	}

	public void setMeasuredAt(Date measuredAt) {
		this.measuredAt = measuredAt;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
}