package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userDetails", propOrder = { "_id", "userId", "lastName", "firstName", "gender", "email", "mobilePhone",
		"postcode", "createdAt", "updatedAt", "deletedAt" })
@XmlRootElement(name = "userDetails")
public class UserDetails {

	private ObjectId _id;
	private Integer userId;
	private String firstName;
	private String lastName;
	private String gender;
	private String email;
	private String mobilePhone;
	private Integer postcode;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;

	public UserDetails() {
	}

	public UserDetails(ObjectId _id, Integer userId, String firstName, String lastName, String gender, String email,
			String mobilePhone, Integer postcode, Date createdAt, Date updatedAt, Date deletedAt) {
		this._id = _id;
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.mobilePhone = mobilePhone;
		this.postcode = postcode;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public Integer getPostcode() {
		return postcode;
	}

	public void setPostcode(Integer postcode) {
		this.postcode = postcode;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
}