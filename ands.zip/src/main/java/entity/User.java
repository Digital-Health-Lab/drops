package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "user", propOrder = { "_id", "userId", "username", "password", "userType", "userStatus",
		"activateToken", "accessToken", "createdAt", "updatedAt", "deletedAt", "lastLoginAt" })
@XmlRootElement(name = "user")
public class User {

	private ObjectId _id;
	private Integer userId;
	private String username;
	private String password;
	private String userType;
	private String userStatus;
	private String activateToken;
	private String accessToken;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;
	private Date lastLoginAt;

	public User() {
	}

	public User(ObjectId _id, Integer userId, String username, String password, String userType, String userStatus,
			String activateToken, String accessToken, Date createdAt, Date updatedAt, Date deletedAt,
			Date lastLoginAt) {
		this._id = _id;
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.userType = userType;
		this.userStatus = userStatus;
		this.activateToken = activateToken;
		this.accessToken = accessToken;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
		this.lastLoginAt = lastLoginAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getActivateToken() {
		return activateToken;
	}

	public void setActivateToken(String activateToken) {
		this.activateToken = activateToken;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}

	public Date getLastLoginAt() {
		return lastLoginAt;
	}

	public void setLastLoginAt(Date lastLoginAt) {
		this.lastLoginAt = lastLoginAt;
	}
}