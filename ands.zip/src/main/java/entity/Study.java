package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "study", propOrder = { "_id", "studyId", "userId", "title", "contributors", "catgeories", "fileType",
		"keywords", "description", "references", "funding", "licence", "createdAt", "updatedAt", "deletedAt" })
@XmlRootElement(name = "study")
public class Study {

	private ObjectId _id;
	private Integer studyId;
	private Integer userId;
	private String title;
	private String contributors;
	private String catgeories;
	private String fileType;
	private String keywords;
	private String description;
	private String references;
	private String funding;
	private String licence;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;

	public Study() {
	}

	public Study(ObjectId _id, Integer studyId, Integer userId, String title, String contributors, String catgeories,
			String fileType, String keywords, String description, String references, String funding, String licence,
			Date createdAt, Date updatedAt, Date deletedAt) {
		this._id = _id;
		this.studyId = studyId;
		this.userId = userId;
		this.title = title;
		this.contributors = contributors;
		this.catgeories = catgeories;
		this.fileType = fileType;
		this.keywords = keywords;
		this.description = description;
		this.references = references;
		this.funding = funding;
		this.licence = licence;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getStudyId() {
		return studyId;
	}

	public void setStudyId(Integer studyId) {
		this.studyId = studyId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContributors() {
		return contributors;
	}

	public void setContributors(String contributors) {
		this.contributors = contributors;
	}

	public String getCatgeories() {
		return catgeories;
	}

	public void setCatgeories(String catgeories) {
		this.catgeories = catgeories;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReferences() {
		return references;
	}

	public void setReferences(String references) {
		this.references = references;
	}

	public String getFunding() {
		return funding;
	}

	public void setFunding(String funding) {
		this.funding = funding;
	}

	public String getLicence() {
		return licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
}