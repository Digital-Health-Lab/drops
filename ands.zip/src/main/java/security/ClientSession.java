package security;

import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientSession")
public class ClientSession {

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ClientSession() {
	}

	public HttpSession getSession() {
		return (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
	}

	public HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}

	public void setUserInfo(String username, Integer userId) {
		HttpSession session = getSession();
		if (session != null) {
			session.setAttribute("username", myNullChecker.cns(username));
			session.setAttribute("userId", myNullChecker.cni(userId));
		}
	}

	public void setUserName(String firstName, String lastName) {
		HttpSession session = getSession();
		if (session != null) {
			session.setAttribute("firstName", myNullChecker.cns(firstName));
			session.setAttribute("lastName", myNullChecker.cns(lastName));
		}
	}

	public String getUsername() {
		HttpSession session = getSession();
		if (session != null) {
			return myNullChecker.cns(session.getAttribute("username"), null);
		} else {
			return null;
		}
	}

	public Integer getUserId() {
		HttpSession session = getSession();
		if (session != null) {
			return myNullChecker.cni(session.getAttribute("userId"), null);
		} else {
			return null;
		}
	}

	public String getUserName() {
		HttpSession session = getSession();
		if (session != null) {
			String userName = myNullChecker.cns(session.getAttribute("firstName")) + " "
					+ myNullChecker.cns(session.getAttribute("lastName"));
			return myNullChecker.cns(userName, null);
		} else {
			return null;
		}
	}
}