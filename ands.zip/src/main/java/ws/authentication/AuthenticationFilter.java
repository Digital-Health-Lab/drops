package ws.authentication;

import io.jsonwebtoken.Jwts;
import java.io.IOException;
import java.security.Key;
import javax.annotation.Priority;
import javax.inject.Inject;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;
import org.jboss.resteasy.core.Headers;
import org.jboss.resteasy.core.ServerResponse;
import util.MyKeyGenerator;

@Secured
@Provider
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationFilter implements ContainerRequestFilter {

	@Inject
	private MyKeyGenerator keyGenerator;

	private static final String AUTHENTICATION_SCHEME = "Bearer";
	private static final ServerResponse INVALID_AUTHORIZATION_HEADER = new ServerResponse(
			"Authorization failed: authorization header must be provided.", Status.UNAUTHORIZED.getStatusCode(),
			new Headers<Object>());;
	private static final ServerResponse INVALID_ACCESS_TOKEN = new ServerResponse(
			"Authorization failed: invalid access token.", Status.UNAUTHORIZED.getStatusCode(), new Headers<Object>());;

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		// Get the HTTP Authorization header from the request
		String authorizationHeader = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);

		// Check if the HTTP Authorization header is present and formatted
		// correctly
		if (authorizationHeader == null || !authorizationHeader.startsWith(AUTHENTICATION_SCHEME + " ")) {
			requestContext.abortWith(INVALID_AUTHORIZATION_HEADER);
			return;
		}

		// Extract the token from the HTTP Authorization header
		String token = authorizationHeader.substring(AUTHENTICATION_SCHEME.length()).trim();

		try {
			// Validate the token
			validateToken(token);
		} catch (Exception e) {
			requestContext.abortWith(INVALID_ACCESS_TOKEN);
			return;
		}
	}

	private void validateToken(String token) throws Exception {
		// Check if it was issued by the server and if it's not expired
		// Throw an Exception if the token is invalid
		Key key = keyGenerator.generateKey();
		Jwts.parser().setSigningKey(key).parseClaimsJws(token);
	}
}