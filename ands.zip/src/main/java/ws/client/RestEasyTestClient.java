package ws.client;

import static java.lang.System.out;

import java.util.Date;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import entity.UserDetails;
import ws.model.GenericResponse;

public class RestEasyTestClient {

	public static void main(String[] args) {

		ResteasyClient client = new ResteasyClientBuilder().build();

		// GET example
		ResteasyWebTarget getDummy = client.target("http://localhost:8080/ands/api/v1");

		Response getDummyResponse = getDummy.request().get();

		String value = getDummyResponse.readEntity(String.class);
		out.println(value);
		getDummyResponse.close();

		// POST example
		UserDetails userDetails = new UserDetails();
		userDetails.setUserId(10);
		userDetails.setFirstName("client");
		userDetails.setLastName("test");
		userDetails.setGender("Female");
		userDetails.setEmail("something");
		userDetails.setMobilePhone("84531531");
		userDetails.setPostcode(5000);
		userDetails.setCreatedAt(new Date());
		userDetails.setUpdatedAt(new Date());

		ResteasyWebTarget add = client.target("http://localhost:8080/ands/api/v1/adduser");
		Response addResponse = add.request().post(Entity.entity(userDetails, MediaType.APPLICATION_JSON));
		out.println(addResponse.readEntity(GenericResponse.class));
		out.println("HTTP Response Code:" + addResponse.getStatus());
		addResponse.close();

		addResponse = add.request().post(Entity.entity(userDetails, MediaType.APPLICATION_JSON));
		out.println(addResponse.readEntity(GenericResponse.class));
		out.println("HTTP Response Code:" + addResponse.getStatus());
		addResponse.close();

		// DELETE example
		ResteasyWebTarget delete = client.target("http://localhost:8080/ands/api/v1/deleteuser");
		Response deleteResponse = delete.request().delete();
		out.println(deleteResponse.readEntity(GenericResponse.class));
		out.println("HTTP Response Code:" + deleteResponse.getStatus());
		deleteResponse.close();

		deleteResponse = delete.request().delete();
		out.println(deleteResponse.readEntity(GenericResponse.class));
		out.println("HTTP Response Code:" + deleteResponse.getStatus());
		deleteResponse.close();
	}
}