package ws.server;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import entity.ResearchData;
import entity.UserDetails;
import ws.authentication.Secured;

/**
 *
 * @author Moroker
 *
 */

@Path("/v1")
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public interface ServiceInterface {

	@GET
	@Path("/")
	@Produces({ MediaType.APPLICATION_JSON })
	Response index();

	@GET
	@Path("/name/{param}")
	@Produces({ MediaType.TEXT_PLAIN })
	Response printMessage(@PathParam("param") String msg);

	@GET
	@Path("/userdetails/list")
	List<UserDetails> listUserDetails();

	@GET
	@Secured
	@Path("/userdetails/get")
	List<UserDetails> getUserDetailsByUserId(@QueryParam("userId") Integer userId);

	@POST
	@Secured
	@Path("/userdetails/add")
	Response addUserDetails(UserDetails userDetails);

	@PUT
	@Secured
	@Path("/userdetails/update")
	Response updateUserDetails(UserDetails userDetails);

	@DELETE
	@Secured
	@Path("/userdetails/delete")
	Response deleteUserDetails(@QueryParam("userId") Integer userId);

	@POST
	@Secured
	@Path("/data/add")
	Response addResearchData(ResearchData researchData);

	@PUT
	@Secured
	@Path("/data/update")
	Response updateResearchData(ResearchData researchData);

	@GET
	@Secured
	@Path("/data/getbystudy")
	// @Consumes({ MediaType.APPLICATION_JSON })
	List<ResearchData> getResearchDataByStudyId(@QueryParam("studyId") Integer studyId);

	@GET
	@Secured
	@Path("/data/getbyuser")
	List<ResearchData> getResearchDataByUserId(@QueryParam("userId") Integer userId);
}