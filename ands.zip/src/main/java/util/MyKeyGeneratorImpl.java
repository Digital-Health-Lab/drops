package util;

import java.security.Key;
import javax.crypto.spec.SecretKeySpec;

public class MyKeyGeneratorImpl implements MyKeyGenerator {

	// ======================================
	// = Business methods =
	// ======================================

	@Override
	public Key generateKey() {
		String keyString = "moroker";
		Key key = new SecretKeySpec(keyString.getBytes(), 0, keyString.getBytes().length, "DES");
		return key;
	}
}