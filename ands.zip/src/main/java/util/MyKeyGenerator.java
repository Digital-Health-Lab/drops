package util;

import java.security.Key;

public interface MyKeyGenerator {

	Key generateKey();
}