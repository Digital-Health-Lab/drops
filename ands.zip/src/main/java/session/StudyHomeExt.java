package session;

import com.mongodb.client.model.Filters;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.ejb.Stateless;

import entity.Study;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StudyHomeExt extends StudyHome {

	private static final Logger LOGGER = Logger.getLogger(StudyHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<Study> queryByStudy(Study study) {
		if (study == null) {
			return null;
		}

		List<Study> list = find(Filters.eq("_id", study.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryLikeKeywordsIns(String keywords) {
		keywords = myNullChecker.cns(keywords);
		if (keywords.equals("")) {
			return null;
		}

		Pattern pattern = Pattern.compile(".*" + Pattern.quote(keywords) + ".*", Pattern.CASE_INSENSITIVE);

		List<Study> list = find(Filters.regex("keywords", pattern));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}