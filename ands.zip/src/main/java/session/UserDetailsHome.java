package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.UserDetails;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class UserDetailsHome {

	private static final Logger LOGGER = Logger.getLogger(UserDetailsHome.class.getName());
	private static final String COLLECTION = "user_details";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(UserDetails userDetails) {
		try {
			if (connectCollection() && userDetails != null) {
				Document document = new Document().append("userId", userDetails.getUserId())
						.append("firstName", userDetails.getFirstName()).append("lastName", userDetails.getLastName())
						.append("gender", userDetails.getGender()).append("email", userDetails.getEmail())
						.append("mobilePhone", userDetails.getMobilePhone())
						.append("postcode", userDetails.getPostcode()).append("createdAt", new Date())
						.append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(UserDetails userDetails) {
		try {
			if (connectCollection() && userDetails != null) {
				Document document = new Document().append("firstName", userDetails.getFirstName())
						.append("lastName", userDetails.getLastName()).append("gender", userDetails.getGender())
						.append("email", userDetails.getEmail()).append("mobilePhone", userDetails.getMobilePhone())
						.append("postcode", userDetails.getPostcode()).append("updatedAt", new Date())
						.append("deletedAt", userDetails.getDeletedAt());

				dbDAO.updateData(new Document("_id", userDetails.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(UserDetails userDetails) {
		try {
			if (connectCollection() && userDetails != null) {
				dbDAO.deleteData(new Document("_id", userDetails.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<UserDetails> find(Bson regexQuery) {
		final List<UserDetails> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					// out.println(document.getObjectId("_id").toHexString());
					out.println(document.toJson());
					// iDocument.documentToMap(document.toJson());
					// list.add(new Gson().fromJson(document.toJson(),
					// UserDetails.class));

					UserDetails userDetails = new UserDetails(document.getObjectId("_id"),
							document.getInteger("userId"), document.getString("firstName"),
							document.getString("lastName"), document.getString("gender"), document.getString("email"),
							document.getString("mobilePhone"), document.getInteger("postcode"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(userDetails);
				});

				// iter.forEach(new Block<Document>() {
				// @Override
				// public void apply(final Document doc) {
				// out.println(doc.toJson());
				// }
				// });
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public UserDetails trimInput(UserDetails userDetails) {
		if (userDetails != null) {
			userDetails.setFirstName(myNullChecker.cns(userDetails.getFirstName(), null));
			userDetails.setLastName(myNullChecker.cns(userDetails.getLastName(), null));
			userDetails.setGender(myNullChecker.cns(userDetails.getGender(), null));
			String email = myNullChecker.cns(userDetails.getEmail(), null);
			if (email != null) {
				email = email.toLowerCase();
			}
			userDetails.setEmail(email);
			userDetails.setMobilePhone(myNullChecker.cns(userDetails.getMobilePhone(), null));
			userDetails.setPostcode(myNullChecker.cni(userDetails.getPostcode(), null));
		}

		return userDetails;
	}
}