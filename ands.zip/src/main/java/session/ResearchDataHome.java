package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.ResearchData;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class ResearchDataHome {

	private static final Logger LOGGER = Logger.getLogger(ResearchDataHome.class.getName());
	private static final String COLLECTION = "research_data";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(ResearchData researchData) {
		try {
			if (connectCollection() && researchData != null) {
				Document document = new Document().append("studyId", researchData.getStudyId())
						.append("variableName", researchData.getVariableName())
						.append("variableSource", researchData.getVariableSource())
						.append("value", researchData.getValue()).append("linkageKey", researchData.getLinkageKey())
						.append("measuredAt", researchData.getMeasuredAt()).append("createdAt", new Date())
						.append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(ResearchData researchData) {
		try {
			if (connectCollection() && researchData != null) {
				Document document = new Document().append("studyId", researchData.getStudyId())
						.append("variableName", researchData.getVariableName())
						.append("variableSource", researchData.getVariableSource())
						.append("value", researchData.getValue()).append("linkageKey", researchData.getLinkageKey())
						.append("measuredAt", researchData.getMeasuredAt()).append("updatedAt", new Date());

				dbDAO.updateData(new Document("_id", researchData.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(ResearchData researchData) {
		try {
			if (connectCollection() && researchData != null) {
				dbDAO.deleteData(new Document("_id", researchData.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<ResearchData> find(Bson regexQuery) {
		final List<ResearchData> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					ResearchData researchData = new ResearchData(document.getObjectId("_id"),
							document.getInteger("studyId"), document.getString("variableName"),
							document.getString("variableSource"), document.getString("value"),
							document.getString("linkageKey"), document.getDate("measuredAt"),
							document.getDate("createdAt"), document.getDate("updatedAt"));
					list.add(researchData);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public List<ResearchData> find(List<Bson> regexQueryList) {
		final List<ResearchData> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				AggregateIterable<Document> iter = dbDAO.searchData(regexQueryList);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					ResearchData researchData = new ResearchData(document.getObjectId("_id"),
							document.getInteger("studyId"), document.getString("variableName"),
							document.getString("variableSource"), document.getString("value"),
							document.getString("linkageKey"), document.getDate("measuredAt"),
							document.getDate("createdAt"), document.getDate("updatedAt"));
					list.add(researchData);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return list;
	}

	public ResearchData trimInput(ResearchData researchData) {
		if (researchData != null) {
			researchData.setVariableName(myNullChecker.cns(researchData.getVariableName(), null));
			researchData.setVariableSource(myNullChecker.cns(researchData.getVariableSource(), null));
			researchData.setValue(myNullChecker.cns(researchData.getValue(), null));
			researchData.setLinkageKey(myNullChecker.cns(researchData.getLinkageKey(), null));
		}

		return researchData;
	}
}