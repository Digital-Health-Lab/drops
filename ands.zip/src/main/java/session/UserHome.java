package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.model.Filters;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.User;
import entity.UserDetails;
import util.MyNullChecker;
import util.MyUuid;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class UserHome {

	private static final Logger LOGGER = Logger.getLogger(UserHome.class.getName());
	private static final String COLLECTION = "user";

	private DatabaseCRUD dbDAO = null;

	@EJB
	private UserDetailsHome userDetailsHome;

	private MyNullChecker myNullChecker = new MyNullChecker();
	private MyUuid uuid = new MyUuid();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(User user) {
		try {
			if (connectCollection() && user != null) {
				Document document = new Document().append("userId", dbDAO.getTotalCount(null) + 1)
						.append("username", user.getUsername()).append("password", user.getPassword())
						.append("userType", user.getUserType()).append("userStatus", user.getUserStatus())
						.append("activateToken", uuid.randomId()).append("accessToken", uuid.randomId())
						.append("createdAt", new Date()).append("updatedAt", new Date());

				dbDAO.insertData(document);

				// Create userDetails with userId and email
				UserDetails userDetails = new UserDetails();
				userDetails.setUserId(document.getInteger("userId"));
				userDetails.setEmail(document.getString("username"));
				if (userDetailsHome.create(userDetails) != null) {
					return document.getObjectId("_id");
				}
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(User user) {
		try {
			if (connectCollection() && user != null) {
				Document document = new Document().append("userId", user.getUserId())
						.append("username", user.getUsername()).append("password", user.getPassword())
						.append("userType", user.getUserType()).append("userStatus", user.getUserStatus())
						.append("activateToken", user.getActivateToken()).append("accessToken", user.getAccessToken())
						.append("updatedAt", new Date()).append("deletedAt", user.getDeletedAt())
						.append("lastLoginAt", user.getLastLoginAt());

				dbDAO.updateData(new Document("_id", user.get_id()), document);

				// Update userDetails with email and deletedAt
				List<UserDetails> userDetailsList = userDetailsHome.find(Filters.eq("userId", user.getUserId()));
				if (userDetailsList != null && userDetailsList.size() > 0) {
					for (UserDetails userDetails : userDetailsList) {
						userDetails.setEmail(user.getUsername());
						userDetails.setDeletedAt(user.getDeletedAt());
						userDetailsHome.update(userDetails);
					}
				}

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(User user) {
		try {
			if (connectCollection() && user != null) {
				// Delete userDetails
				List<UserDetails> userDetailsList = userDetailsHome.find(Filters.eq("userId", user.getUserId()));
				if (userDetailsList != null && userDetailsList.size() > 0) {
					for (UserDetails userDetails : userDetailsList) {
						userDetailsHome.delete(userDetails);
					}
				}

				dbDAO.deleteData(new Document("_id", user.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<User> find(Bson regexQuery) {
		final List<User> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					User user = new User(document.getObjectId("_id"), document.getInteger("userId"),
							document.getString("username"), document.getString("password"),
							document.getString("userType"), document.getString("userStatus"),
							document.getString("activateToken"), document.getString("accessToken"),
							document.getDate("createdAt"), document.getDate("updatedAt"), document.getDate("deletedAt"),
							document.getDate("lastLoginAt"));
					list.add(user);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public User trimInput(User user) {
		if (user != null) {
			user.setUsername(myNullChecker.cns(user.getUsername()).toLowerCase());
			user.setPassword(myNullChecker.cns(user.getPassword()));
			user.setUserType(myNullChecker.cns(user.getUserType()));
			user.setUserStatus(myNullChecker.cns(user.getUserStatus()));
		}

		return user;
	}
}