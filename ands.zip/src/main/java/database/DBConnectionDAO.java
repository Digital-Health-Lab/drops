package database;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.MongoException;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.io.IOException;
import java.util.Arrays;
import org.bson.Document;

import constant.Constants;

/**
 * @author Moroker
 *
 */
public class DBConnectionDAO {

	protected MongoDatabase mongoDatabase;
	protected MongoCollection<Document> collection;
	protected MongoClient mongoClient;

	public void openDB() throws MongoException, IOException {
		// Default Authentication
		MongoCredential credential = MongoCredential.createCredential(Constants.USERNAME, Constants.DATABASE,
				Constants.PASSWORD);

		// connect to the local database server
		mongoClient = new MongoClient(new ServerAddress(Constants.HOST_NAME_LOCAL, Constants.DB_PORT),
				Arrays.asList(credential));
		// mongoClient = new MongoClient(new
		// MongoClientURI("mongodb://yang:123123@localhost/?authSource=mydb"));

		// get handle to "mydb" database
		// if database doesn't exists, mongoDB will create it automatically
		mongoDatabase = mongoClient.getDatabase(Constants.DATABASE);
	}

	public boolean connectDBCollection(String collectionName) {
		if (collectionName == null || collectionName.isEmpty()) {
			return false;
		}
		collection = mongoDatabase.getCollection(collectionName);

		return true;
	}

	public void closeDB() {
		mongoClient.close();
	}
}