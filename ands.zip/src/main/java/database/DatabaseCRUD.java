package database;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

/**
 * @author Moroker
 *
 */
public class DatabaseCRUD extends DBConnectionDAO {

	public MongoCollection<Document> getCollection() {
		return collection;
	}

	public void insertData(Document document) {
		if (collection != null && document != null) {
			collection.insertOne(document);
		}
	}

	public void updateData(Bson searchQuery, Document document) {
		if (collection != null && searchQuery != null && document != null) {
			collection.updateOne(searchQuery, new Document("$set", document));
		}
	}

	public FindIterable<Document> searchData(Bson searchQuery) {
		if (collection != null) {
			return searchQuery != null ? collection.find(searchQuery) : collection.find();
		}

		return null;
	}

	public AggregateIterable<Document> searchData(List<Bson> searchQueryList) {
		if (collection != null) {
		//if (collection != null && searchQueryList != null) {
			//return collection.aggregate(searchQueryList);
			return searchQueryList != null ? collection.aggregate(searchQueryList) : collection.aggregate(null);
		}

		return null;
	}

	public void deleteData(Bson searchQuery) {
		if (collection != null && searchQuery != null) {
			collection.deleteOne(searchQuery);
		}
	}

	public int getTotalCount(Bson searchQuery) {
		if (collection != null) {
			return (int) (searchQuery != null ? collection.count(searchQuery) : collection.count());
		}

		return 0;
	}
}