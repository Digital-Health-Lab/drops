package session;

import com.mongodb.client.model.Filters;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;

import entity.Participant;
import entity.Study;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class ParticipantHomeExt extends ParticipantHome {

	private static final Logger LOGGER = Logger.getLogger(ParticipantHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<Participant> queryByParticipant(Participant participant) {
		if (participant == null) {
			return null;
		}

		List<Participant> list = find(Filters.eq("_id", participant.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Participant> queryByParticipantId(Integer participantId) {
		participantId = myNullChecker.cni(participantId);
		if (participantId == 0) {
			return null;
		}

		List<Participant> list = find(Filters.eq("participantId", participantId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Participant> queryByStudyId(Integer studyId) {
		studyId = myNullChecker.cni(studyId);
		if (studyId == 0) {
			return null;
		}

		List<Participant> list = find(Filters.eq("studyId", studyId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Participant> queryByStudyUserId(Integer studyUserId) {
		studyUserId = myNullChecker.cni(studyUserId);
		if (studyUserId == 0) {
			return null;
		}

		Bson bsonLookup = new Document("$lookup", new Document("from", "study").append("localField", "studyId")
				.append("foreignField", "studyId").append("as", "study"));
		Bson bsonMatch = new Document("$match", new Document("study.userId", studyUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch);

		List<Participant> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Participant> queryByStudyId(Integer studyId, Integer loggedInUserId) {
		studyId = myNullChecker.cni(studyId);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (studyId == 0 || loggedInUserId == 0) {
			return null;
		}

		Bson bsonMatch1 = new Document("$match", new Document("studyId", studyId));
		Bson bsonLookup = new Document("$lookup", new Document("from", "study").append("localField", "studyId")
				.append("foreignField", "studyId").append("as", "study"));
		Bson bsonMatch2 = new Document("$match", new Document("study.userId", loggedInUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonMatch1);
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch2);

		List<Participant> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}