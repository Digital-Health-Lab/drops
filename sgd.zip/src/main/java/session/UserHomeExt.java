package session;

import com.mongodb.client.model.Filters;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.ejb.Stateless;

import entity.User;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class UserHomeExt extends UserHome {

	private static final Logger LOGGER = Logger.getLogger(UserHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<User> queryByUser(User user) {
		if (user == null) {
			return null;
		}

		List<User> list = find(Filters.eq("_id", user.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<User> queryByUserId(Integer userId) {
		userId = myNullChecker.cni(userId);
		if (userId == 0) {
			return null;
		}

		List<User> list = find(Filters.eq("userId", userId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<User> queryByUsername(String username) {
		username = myNullChecker.cns(username).toLowerCase();
		if (username.equals("")) {
			return null;
		}

		List<User> list = find(Filters.eq("username", username));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<User> queryByUsernameAndPassword(String username, String password) {
		username = myNullChecker.cns(username).toLowerCase();
		password = myNullChecker.cns(password);
		if (username.equals("") || password.equals("")) {
			return null;
		}

		List<User> list = find(Filters.and(Filters.eq("username", username), Filters.eq("password", password)));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<User> queryLikeUsernameIns(String username) {
		username = myNullChecker.cns(username);
		if (username.equals("")) {
			return null;
		}

		Pattern pattern = Pattern.compile(".*" + Pattern.quote(username) + ".*", Pattern.CASE_INSENSITIVE);

		List<User> list = find(Filters.regex("username", pattern));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}