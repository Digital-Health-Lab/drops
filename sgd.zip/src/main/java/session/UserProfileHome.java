package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.UserProfile;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class UserProfileHome {

	private static final Logger LOGGER = Logger.getLogger(UserProfileHome.class.getName());
	private static final String COLLECTION = "user_profile";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(UserProfile userProfile) {
		try {
			if (connectCollection() && userProfile != null) {
				Document document = new Document().append("userId", userProfile.getUserId())
						.append("firstName", userProfile.getFirstName()).append("lastName", userProfile.getLastName())
						.append("email", userProfile.getEmail()).append("mobilePhone", userProfile.getMobilePhone())
						.append("createdAt", new Date()).append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(UserProfile userProfile) {
		try {
			if (connectCollection() && userProfile != null) {
				Document document = new Document().append("firstName", userProfile.getFirstName())
						.append("lastName", userProfile.getLastName()).append("email", userProfile.getEmail())
						.append("mobilePhone", userProfile.getMobilePhone()).append("updatedAt", new Date())
						.append("deletedAt", userProfile.getDeletedAt());

				dbDAO.updateData(new Document("_id", userProfile.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(UserProfile userProfile) {
		try {
			if (connectCollection() && userProfile != null) {
				dbDAO.deleteData(new Document("_id", userProfile.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<UserProfile> find(Bson regexQuery) {
		final List<UserProfile> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					UserProfile userProfile = new UserProfile(document.getObjectId("_id"),
							document.getInteger("userId"), document.getString("firstName"),
							document.getString("lastName"), document.getString("email"),
							document.getString("mobilePhone"), document.getDate("createdAt"),
							document.getDate("updatedAt"), document.getDate("deletedAt"));
					list.add(userProfile);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public UserProfile trimInput(UserProfile userProfile) {
		if (userProfile != null) {
			userProfile.setFirstName(myNullChecker.cns(userProfile.getFirstName(), null));
			userProfile.setLastName(myNullChecker.cns(userProfile.getLastName(), null));
			String email = myNullChecker.cns(userProfile.getEmail(), null);
			if (email != null) {
				email = email.toLowerCase();
			}
			userProfile.setEmail(email);
			userProfile.setMobilePhone(myNullChecker.cns(userProfile.getMobilePhone(), null));
		}

		return userProfile;
	}
}