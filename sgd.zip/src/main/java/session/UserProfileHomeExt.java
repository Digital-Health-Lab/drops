package session;

import com.mongodb.client.model.Filters;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.ejb.Stateless;
import org.bson.conversions.Bson;

import entity.UserProfile;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class UserProfileHomeExt extends UserProfileHome {

	private static final Logger LOGGER = Logger.getLogger(UserProfileHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<UserProfile> queryByUserProfile(UserProfile userProfile) {
		if (userProfile == null) {
			return null;
		}

		List<UserProfile> list = find(Filters.eq("_id", userProfile.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<UserProfile> queryByUserId(Integer userId) {
		userId = myNullChecker.cni(userId);
		if (userId == 0) {
			return null;
		}

		List<UserProfile> list = find(Filters.eq("userId", userId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<UserProfile> queryLikeUserProfileIns(String firstName, String lastName, String email,
			String mobilePhone) {
		firstName = myNullChecker.cns(firstName);
		lastName = myNullChecker.cns(lastName);
		email = myNullChecker.cns(email);
		mobilePhone = myNullChecker.cns(mobilePhone);
		if (firstName.equals("") && lastName.equals("") && email.equals("") && mobilePhone.equals("")) {
			return null;
		}

		Bson bsonFilter = null;
		Pattern pattern = null;
		if (!firstName.equals("")) {
			pattern = Pattern.compile(".*" + Pattern.quote(firstName) + ".*", Pattern.CASE_INSENSITIVE);
			bsonFilter = Filters.regex("firstName", pattern);
		}
		if (!lastName.equals("")) {
			pattern = Pattern.compile(".*" + Pattern.quote(lastName) + ".*", Pattern.CASE_INSENSITIVE);

			if (bsonFilter != null) {
				bsonFilter = Filters.and(bsonFilter, Filters.regex("lastName", pattern));
			} else {
				bsonFilter = Filters.regex("lastName", pattern);
			}
		}
		if (!email.equals("")) {
			pattern = Pattern.compile(".*" + Pattern.quote(email) + ".*", Pattern.CASE_INSENSITIVE);

			if (bsonFilter != null) {
				bsonFilter = Filters.and(bsonFilter, Filters.regex("email", pattern));
			} else {
				bsonFilter = Filters.regex("email", pattern);
			}
		}
		if (!mobilePhone.equals("")) {
			pattern = Pattern.compile(".*" + Pattern.quote(mobilePhone) + ".*", Pattern.CASE_INSENSITIVE);

			if (bsonFilter != null) {
				bsonFilter = Filters.and(bsonFilter, Filters.regex("mobilePhone", pattern));
			} else {
				bsonFilter = Filters.regex("mobilePhone", pattern);
			}
		}

		List<UserProfile> list = find(bsonFilter);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}