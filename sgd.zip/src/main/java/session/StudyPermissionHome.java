package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.StudyPermission;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StudyPermissionHome {

	private static final Logger LOGGER = Logger.getLogger(StudyPermissionHome.class.getName());
	private static final String COLLECTION = "study_permission";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(StudyPermission studyPermission) {
		try {
			if (connectCollection() && studyPermission != null) {
				Document document = new Document().append("studyPermissionId", dbDAO.getTotalCount(null) + 1)
						.append("studyId", studyPermission.getStudyId()).append("userId", studyPermission.getUserId())
						.append("permissionStatus", studyPermission.getPermissionStatus())
						.append("createdAt", new Date()).append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(StudyPermission studyPermission) {
		try {
			if (connectCollection() && studyPermission != null) {
				Document document = new Document().append("studyPermissionId", studyPermission.getStudyPermissionId())
						.append("studyId", studyPermission.getStudyId()).append("userId", studyPermission.getUserId())
						.append("permissionStatus", studyPermission.getPermissionStatus())
						.append("updatedAt", new Date()).append("deletedAt", studyPermission.getDeletedAt());

				dbDAO.updateData(new Document("_id", studyPermission.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(StudyPermission studyPermission) {
		try {
			if (connectCollection() && studyPermission != null) {
				dbDAO.deleteData(new Document("_id", studyPermission.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<StudyPermission> find(Bson regexQuery) {
		final List<StudyPermission> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					StudyPermission studyPermission = new StudyPermission(document.getObjectId("_id"),
							document.getInteger("studyPermissionId"), document.getInteger("studyId"),
							document.getInteger("userId"), document.getString("permissionStatus"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(studyPermission);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public List<StudyPermission> find(List<Bson> regexQueryList) {
		final List<StudyPermission> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				AggregateIterable<Document> iter = dbDAO.searchData(regexQueryList);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					StudyPermission studyPermission = new StudyPermission(document.getObjectId("_id"),
							document.getInteger("studyPermissionId"), document.getInteger("studyId"),
							document.getInteger("userId"), document.getString("permissionStatus"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(studyPermission);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return list;
	}

	public StudyPermission trimInput(StudyPermission studyPermission) {
		if (studyPermission != null) {
			studyPermission.setPermissionStatus(myNullChecker.cns(studyPermission.getPermissionStatus(), null));
		}

		return studyPermission;
	}
}