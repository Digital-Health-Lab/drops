package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.Source;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class SourceHome {

	private static final Logger LOGGER = Logger.getLogger(SourceHome.class.getName());
	private static final String COLLECTION = "source";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(Source source) {
		try {
			if (connectCollection() && source != null) {
				Document document = new Document().append("sourceId", dbDAO.getTotalCount(null) + 1)
						.append("name", source.getName()).append("model", source.getModel())
						.append("version", source.getVersion()).append("wearType", source.getWearType())
						.append("wearPosition", source.getWearPosition())
						.append("wearPositionOther", source.getWearPositionOther())
						.append("variableName", source.getVariableName())
						.append("variableValue", source.getVariableValue()).append("addData", source.getAddData())
						.append("createdAt", new Date()).append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(Source source) {
		try {
			if (connectCollection() && source != null) {
				Document document = new Document().append("sourceId", source.getSourceId())
						.append("name", source.getName()).append("model", source.getModel())
						.append("version", source.getVersion()).append("wearType", source.getWearType())
						.append("wearPosition", source.getWearPosition())
						.append("wearPositionOther", source.getWearPositionOther())
						.append("variableName", source.getVariableName())
						.append("variableValue", source.getVariableValue()).append("addData", source.getAddData())
						.append("updatedAt", new Date()).append("deletedAt", source.getDeletedAt());

				dbDAO.updateData(new Document("_id", source.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(Source source) {
		try {
			if (connectCollection() && source != null) {
				dbDAO.deleteData(new Document("_id", source.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<Source> find(Bson regexQuery) {
		final List<Source> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					Source source = new Source(document.getObjectId("_id"), document.getInteger("sourceId"),
							document.getString("name"), document.getString("model"), document.getString("version"),
							document.getString("wearType"), document.getString("wearPosition"),
							document.getString("wearPositionOther"), document.getString("variableName"),
							document.getString("variableValue"), document.getString("addData"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(source);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public Source trimInput(Source source) {
		if (source != null) {
			source.setName(myNullChecker.cns(source.getName(), null));
			source.setModel(myNullChecker.cns(source.getModel(), null));
			source.setVersion(myNullChecker.cns(source.getVersion(), null));
			source.setWearType(myNullChecker.cns(source.getWearType(), null));
			source.setWearPosition(myNullChecker.cns(source.getWearPositionOther(), null));
			source.setVariableName(myNullChecker.cns(source.getVariableName(), null));
			source.setVariableValue(myNullChecker.cns(source.getVariableValue(), null));
			source.setAddData(myNullChecker.cns(source.getAddData(), null));
		}

		return source;
	}
}