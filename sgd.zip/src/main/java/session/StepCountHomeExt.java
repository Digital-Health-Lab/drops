package session;

import com.mongodb.client.model.Filters;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;

import entity.StepCount;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StepCountHomeExt extends StepCountHome {

	private static final Logger LOGGER = Logger.getLogger(StepCountHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<StepCount> queryByStepCount(StepCount stepCount) {
		if (stepCount == null) {
			return null;
		}

		List<StepCount> list = find(Filters.eq("_id", stepCount.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryByParticipantId(Integer participantId) {
		participantId = myNullChecker.cni(participantId);
		if (participantId == 0) {
			return null;
		}

		List<StepCount> list = find(Filters.eq("participantId", participantId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryByParticipantStudyId(Integer participantStudyId) {
		participantStudyId = myNullChecker.cni(participantStudyId);
		if (participantStudyId == 0) {
			return null;
		}

		Bson bsonLookup = new Document("$lookup",
				new Document("from", "participant").append("localField", "participantId")
						.append("foreignField", "participantId").append("as", "participant"));
		Bson bsonMatch = new Document("$match", new Document("participant.studyId", participantStudyId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch);

		List<StepCount> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryByParticipantStudyUserId(Integer participantStudyUserId) {
		participantStudyUserId = myNullChecker.cni(participantStudyUserId);
		if (participantStudyUserId == 0) {
			return null;
		}

		Bson bsonLookup1 = new Document("$lookup",
				new Document("from", "participant").append("localField", "participantId")
						.append("foreignField", "participantId").append("as", "participant"));
		Bson bsonUnwind1 = new Document("$unwind", "$participant");
		Bson bsonLookup2 = new Document("$lookup", new Document("from", "study")
				.append("localField", "participant.studyId").append("foreignField", "studyId").append("as", "study"));
		Bson bsonUnwind2 = new Document("$unwind", "$study");
		Bson bsonMatch = new Document("$match", new Document("study.userId", participantStudyUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonLookup1);
		bsonFilterList.add(bsonUnwind1);
		bsonFilterList.add(bsonLookup2);
		bsonFilterList.add(bsonUnwind2);
		bsonFilterList.add(bsonMatch);

		List<StepCount> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryBySourceId(Integer sourceId) {
		sourceId = myNullChecker.cni(sourceId);
		if (sourceId == 0) {
			return null;
		}

		List<StepCount> list = find(Filters.eq("sourceId", sourceId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryByParticipantId(Integer participantId, Integer loggedInUserId) {
		participantId = myNullChecker.cni(participantId);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (participantId == 0 || loggedInUserId == 0) {
			return null;
		}

		Bson bsonMatch0 = new Document("$match", new Document("participantId", participantId));

		Bson bsonLookup1 = new Document("$lookup",
				new Document("from", "participant").append("localField", "participantId")
						.append("foreignField", "participantId").append("as", "participant"));
		Bson bsonUnwind1 = new Document("$unwind", "$participant");
		Bson bsonLookup2 = new Document("$lookup", new Document("from", "study")
				.append("localField", "participant.studyId").append("foreignField", "studyId").append("as", "study"));
		Bson bsonUnwind2 = new Document("$unwind", "$study");
		Bson bsonMatch2 = new Document("$match", new Document("study.userId", loggedInUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonMatch0);
		bsonFilterList.add(bsonLookup1);
		bsonFilterList.add(bsonUnwind1);
		bsonFilterList.add(bsonLookup2);
		bsonFilterList.add(bsonUnwind2);
		bsonFilterList.add(bsonMatch2);

		List<StepCount> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryByParticipantStudyId(Integer participantStudyId, Integer loggedInUserId) {
		participantStudyId = myNullChecker.cni(participantStudyId);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (participantStudyId == 0 || loggedInUserId == 0) {
			return null;
		}

		Bson bsonLookup0 = new Document("$lookup",
				new Document("from", "participant").append("localField", "participantId")
						.append("foreignField", "participantId").append("as", "participant"));
		Bson bsonMatch0 = new Document("$match", new Document("participant.studyId", participantStudyId));

		Bson bsonLookup1 = new Document("$lookup",
				new Document("from", "participant").append("localField", "participantId")
						.append("foreignField", "participantId").append("as", "participant"));
		Bson bsonUnwind1 = new Document("$unwind", "$participant");
		Bson bsonLookup2 = new Document("$lookup", new Document("from", "study")
				.append("localField", "participant.studyId").append("foreignField", "studyId").append("as", "study"));
		Bson bsonUnwind2 = new Document("$unwind", "$study");
		Bson bsonMatch2 = new Document("$match", new Document("study.userId", loggedInUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonLookup0);
		bsonFilterList.add(bsonMatch0);
		bsonFilterList.add(bsonLookup1);
		bsonFilterList.add(bsonUnwind1);
		bsonFilterList.add(bsonLookup2);
		bsonFilterList.add(bsonUnwind2);
		bsonFilterList.add(bsonMatch2);

		List<StepCount> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StepCount> queryBySourceId(Integer sourceId, Integer loggedInUserId) {
		sourceId = myNullChecker.cni(sourceId);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (sourceId == 0 || loggedInUserId == 0) {
			return null;
		}

		Bson bsonMatch0 = new Document("$match", new Document("sourceId", sourceId));

		Bson bsonLookup1 = new Document("$lookup",
				new Document("from", "participant").append("localField", "participantId")
						.append("foreignField", "participantId").append("as", "participant"));
		Bson bsonUnwind1 = new Document("$unwind", "$participant");
		Bson bsonLookup2 = new Document("$lookup", new Document("from", "study")
				.append("localField", "participant.studyId").append("foreignField", "studyId").append("as", "study"));
		Bson bsonUnwind2 = new Document("$unwind", "$study");
		Bson bsonMatch2 = new Document("$match", new Document("study.userId", loggedInUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonMatch0);
		bsonFilterList.add(bsonLookup1);
		bsonFilterList.add(bsonUnwind1);
		bsonFilterList.add(bsonLookup2);
		bsonFilterList.add(bsonUnwind2);
		bsonFilterList.add(bsonMatch2);

		List<StepCount> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}