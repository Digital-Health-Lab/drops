package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.Study;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StudyHome {

	private static final Logger LOGGER = Logger.getLogger(StudyHome.class.getName());
	private static final String COLLECTION = "study";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(Study study) {
		try {
			if (connectCollection() && study != null) {
				Document document = new Document().append("studyId", dbDAO.getTotalCount(null) + 1)
						.append("userId", study.getUserId()).append("parentStudyId", study.getParentStudyId())
						.append("title", study.getTitle()).append("description", study.getDescription())
						.append("catgeories", study.getCatgeories()).append("keywords", study.getKeywords())
						.append("fileType", study.getFileType()).append("contributors", study.getContributors())
						.append("references", study.getReferences()).append("funding", study.getFunding())
						.append("licence", study.getLicence()).append("variableName", study.getVariableName())
						.append("variableValue", study.getVariableValue()).append("addData", study.getAddData())
						.append("createdAt", new Date()).append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(Study study) {
		try {
			if (connectCollection() && study != null) {
				Document document = new Document().append("studyId", study.getStudyId())
						.append("userId", study.getUserId()).append("parentStudyId", study.getParentStudyId())
						.append("title", study.getTitle()).append("description", study.getDescription())
						.append("catgeories", study.getCatgeories()).append("keywords", study.getKeywords())
						.append("fileType", study.getFileType()).append("contributors", study.getContributors())
						.append("references", study.getReferences()).append("funding", study.getFunding())
						.append("licence", study.getLicence()).append("variableName", study.getVariableName())
						.append("variableValue", study.getVariableValue()).append("addData", study.getAddData())
						.append("updatedAt", new Date()).append("deletedAt", study.getDeletedAt());

				dbDAO.updateData(new Document("_id", study.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(Study study) {
		try {
			if (connectCollection() && study != null) {
				dbDAO.deleteData(new Document("_id", study.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<Study> find(Bson regexQuery) {
		final List<Study> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					Study study = new Study(document.getObjectId("_id"), document.getInteger("studyId"),
							document.getInteger("userId"), document.getInteger("parentStudyId"),
							document.getString("title"), document.getString("description"),
							document.getString("catgeories"), document.getString("keywords"),
							document.getString("fileType"), document.getString("contributors"),
							document.getString("references"), document.getString("funding"),
							document.getString("licence"), document.getString("variableName"),
							document.getString("variableValue"), document.getString("addData"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(study);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public Study trimInput(Study study) {
		if (study != null) {
			study.setTitle(myNullChecker.cns(study.getTitle(), null));
			study.setDescription(myNullChecker.cns(study.getDescription(), null));
			study.setCatgeories(myNullChecker.cns(study.getCatgeories(), null));
			study.setKeywords(myNullChecker.cns(study.getKeywords(), null));
			study.setFileType(myNullChecker.cns(study.getFileType(), null));
			study.setContributors(myNullChecker.cns(study.getContributors(), null));
			study.setReferences(myNullChecker.cns(study.getReferences(), null));
			study.setFunding(myNullChecker.cns(study.getFunding(), null));
			study.setLicence(myNullChecker.cns(study.getLicence(), null));
			study.setVariableName(myNullChecker.cns(study.getVariableName(), null));
			study.setVariableValue(myNullChecker.cns(study.getVariableValue(), null));
			study.setAddData(myNullChecker.cns(study.getAddData(), null));
		}

		return study;
	}
}