package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.StepCount;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StepCountHome {

	private static final Logger LOGGER = Logger.getLogger(StepCountHome.class.getName());
	private static final String COLLECTION = "step_count";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(StepCount stepCount) {
		try {
			if (connectCollection() && stepCount != null) {
				Document document = new Document().append("participantId", stepCount.getParticipantId())
						.append("sourceId", stepCount.getSourceId()).append("measuredAt", stepCount.getMeasuredAt())
						.append("duration", stepCount.getDuration()).append("steps", stepCount.getSteps())
						.append("xAxis", stepCount.getXAxis()).append("yAxis", stepCount.getYAxis())
						.append("zAxis", stepCount.getZAxis()).append("variableName", stepCount.getVariableName())
						.append("variableValue", stepCount.getVariableValue()).append("addData", stepCount.getAddData())
						.append("createdAt", new Date()).append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(StepCount stepCount) {
		try {
			if (connectCollection() && stepCount != null) {
				Document document = new Document().append("participantId", stepCount.getParticipantId())
						.append("sourceId", stepCount.getSourceId()).append("measuredAt", stepCount.getMeasuredAt())
						.append("duration", stepCount.getDuration()).append("steps", stepCount.getSteps())
						.append("xAxis", stepCount.getXAxis()).append("yAxis", stepCount.getYAxis())
						.append("zAxis", stepCount.getZAxis()).append("variableName", stepCount.getVariableName())
						.append("variableValue", stepCount.getVariableValue()).append("addData", stepCount.getAddData())
						.append("updatedAt", new Date()).append("deletedAt", stepCount.getDeletedAt());

				dbDAO.updateData(new Document("_id", stepCount.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(StepCount stepCount) {
		try {
			if (connectCollection() && stepCount != null) {
				dbDAO.deleteData(new Document("_id", stepCount.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<StepCount> find(Bson regexQuery) {
		final List<StepCount> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					StepCount stepCount = new StepCount(document.getObjectId("_id"),
							document.getInteger("participantId"), document.getInteger("sourceId"),
							document.getDate("measuredAt"), document.getInteger("duration"),
							document.getInteger("steps"), document.getDouble("xAxis"), document.getDouble("yAxis"),
							document.getDouble("zAxis"), document.getString("variableName"),
							document.getString("variableValue"), document.getString("addData"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(stepCount);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public List<StepCount> find(List<Bson> regexQueryList) {
		final List<StepCount> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				AggregateIterable<Document> iter = dbDAO.searchData(regexQueryList);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					StepCount stepCount = new StepCount(document.getObjectId("_id"),
							document.getInteger("participantId"), document.getInteger("sourceId"),
							document.getDate("measuredAt"), document.getInteger("duration"),
							document.getInteger("steps"), document.getDouble("xAxis"), document.getDouble("yAxis"),
							document.getDouble("zAxis"), document.getString("variableName"),
							document.getString("variableValue"), document.getString("addData"),
							document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(stepCount);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return list;
	}

	public StepCount trimInput(StepCount stepCount) {
		if (stepCount != null) {
			stepCount.setDuration(myNullChecker.cni(stepCount.getDuration(), null));
			stepCount.setSteps(myNullChecker.cni(stepCount.getSteps(), null));
			stepCount.setXAxis(myNullChecker.cnd(stepCount.getXAxis(), null));
			stepCount.setYAxis(myNullChecker.cnd(stepCount.getYAxis(), null));
			stepCount.setZAxis(myNullChecker.cnd(stepCount.getZAxis(), null));
			stepCount.setVariableName(myNullChecker.cns(stepCount.getVariableName(), null));
			stepCount.setVariableValue(myNullChecker.cns(stepCount.getVariableValue(), null));
			stepCount.setAddData(myNullChecker.cns(stepCount.getAddData(), null));
		}

		return stepCount;
	}
}