package session;

import com.mongodb.client.model.Filters;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.ejb.Stateless;

import entity.Study;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StudyHomeExt extends StudyHome {

	private static final Logger LOGGER = Logger.getLogger(StudyHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<Study> queryByStudy(Study study) {
		if (study == null) {
			return null;
		}

		List<Study> list = find(Filters.eq("_id", study.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryByStudyId(Integer studyId) {
		studyId = myNullChecker.cni(studyId);
		if (studyId == 0) {
			return null;
		}

		List<Study> list = find(Filters.eq("studyId", studyId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryByUserId(Integer userId) {
		userId = myNullChecker.cni(userId);
		if (userId == 0) {
			return null;
		}

		List<Study> list = find(Filters.eq("userId", userId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryByParentStudyId(Integer parentStudyId) {
		parentStudyId = myNullChecker.cni(parentStudyId);
		if (parentStudyId == 0) {
			return null;
		}

		List<Study> list = find(Filters.eq("parentStudyId", parentStudyId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryLikeKeywordsIns(String keywords) {
		keywords = myNullChecker.cns(keywords);
		if (keywords.equals("")) {
			return null;
		}

		Pattern pattern = Pattern.compile(".*" + Pattern.quote(keywords) + ".*", Pattern.CASE_INSENSITIVE);

		List<Study> list = find(Filters.regex("keywords", pattern));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryByParentStudyId(Integer parentStudyId, Integer loggedInUserId) {
		parentStudyId = myNullChecker.cni(parentStudyId);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (parentStudyId == 0 || loggedInUserId == 0) {
			return null;
		}

		List<Study> list = find(
				Filters.and(Filters.eq("parentStudyId", parentStudyId), Filters.eq("userId", loggedInUserId)));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> queryLikeKeywordsIns(String keywords, Integer loggedInUserId) {
		keywords = myNullChecker.cns(keywords);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (keywords.equals("") || loggedInUserId == 0) {
			return null;
		}

		Pattern pattern = Pattern.compile(".*" + Pattern.quote(keywords) + ".*", Pattern.CASE_INSENSITIVE);

		List<Study> list = find(Filters.and(Filters.regex("keywords", pattern), Filters.eq("userId", loggedInUserId)));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> lookUpAllfromOthers(Integer loggedInUserId) {
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (loggedInUserId == 0) {
			return null;
		}

		// to do
		List<Study> list = find(Filters.ne("userId", loggedInUserId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Study> lookUpSharedfromOthers(Integer loggedInUserId) {
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (loggedInUserId == 0) {
			return null;
		}

		// to do
		List<Study> list = find(Filters.and(Filters.eq("licence", "Public"), Filters.ne("userId", loggedInUserId)));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}