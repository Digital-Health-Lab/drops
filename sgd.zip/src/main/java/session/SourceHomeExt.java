package session;

import com.mongodb.client.model.Filters;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.ejb.Stateless;

import entity.Source;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class SourceHomeExt extends SourceHome {

	private static final Logger LOGGER = Logger.getLogger(SourceHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<Source> queryBySource(Source source) {
		if (source == null) {
			return null;
		}

		List<Source> list = find(Filters.eq("_id", source.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Source> queryBySourceId(Integer sourceId) {
		sourceId = myNullChecker.cni(sourceId);
		if (sourceId == 0) {
			return null;
		}

		List<Source> list = find(Filters.eq("sourceId", sourceId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<Source> queryLikeNameIns(String name) {
		name = myNullChecker.cns(name);
		if (name.equals("")) {
			return null;
		}

		Pattern pattern = Pattern.compile(".*" + Pattern.quote(name) + ".*", Pattern.CASE_INSENSITIVE);

		List<Source> list = find(Filters.regex("name", pattern));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}