package session;

import com.mongodb.client.model.Filters;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;

import entity.StudyPermission;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class StudyPermissionHomeExt extends StudyPermissionHome {

	private static final Logger LOGGER = Logger.getLogger(StudyPermissionHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<StudyPermission> queryByStudyPermission(StudyPermission studyPermission) {
		if (studyPermission == null) {
			return null;
		}

		List<StudyPermission> list = find(Filters.eq("_id", studyPermission.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryByStudyPermissionId(Integer studyPermissionId) {
		studyPermissionId = myNullChecker.cni(studyPermissionId);
		if (studyPermissionId == 0) {
			return null;
		}

		List<StudyPermission> list = find(Filters.eq("studyPermissionId", studyPermissionId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryByStudyId(Integer studyId) {
		studyId = myNullChecker.cni(studyId);
		if (studyId == 0) {
			return null;
		}

		List<StudyPermission> list = find(Filters.eq("studyId", studyId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryByStudyUserId(Integer studyUserId) {
		studyUserId = myNullChecker.cni(studyUserId);
		if (studyUserId == 0) {
			return null;
		}

		Bson bsonLookup = new Document("$lookup", new Document("from", "study").append("localField", "studyId")
				.append("foreignField", "studyId").append("as", "study"));
		Bson bsonMatch = new Document("$match", new Document("study.userId", studyUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch);

		List<StudyPermission> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryByUserId(Integer userId) {
		userId = myNullChecker.cni(userId);
		if (userId == 0) {
			return null;
		}

		List<StudyPermission> list = find(Filters.eq("userId", userId));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryLikePermissionStatusIns(String permissionStatus) {
		permissionStatus = myNullChecker.cns(permissionStatus);
		if (permissionStatus.equals("")) {
			return null;
		}

		Pattern pattern = Pattern.compile(".*" + Pattern.quote(permissionStatus) + ".*", Pattern.CASE_INSENSITIVE);

		List<StudyPermission> list = find(Filters.regex("name", pattern));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryByStudyId(Integer studyId, Integer loggedInUserId) {
		studyId = myNullChecker.cni(studyId);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (studyId == 0 || loggedInUserId == 0) {
			return null;
		}

		Bson bsonMatch1 = new Document("$match", new Document("studyId", studyId));
		Bson bsonLookup = new Document("$lookup", new Document("from", "study").append("localField", "studyId")
				.append("foreignField", "studyId").append("as", "study"));
		Bson bsonMatch2 = new Document("$match", new Document("study.userId", loggedInUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonMatch1);
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch2);

		List<StudyPermission> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<StudyPermission> queryLikePermissionStatusIns(String permissionStatus, Integer loggedInUserId) {
		permissionStatus = myNullChecker.cns(permissionStatus);
		loggedInUserId = myNullChecker.cni(loggedInUserId);
		if (permissionStatus.equals("") || loggedInUserId == 0) {
			return null;
		}

		Bson bsonMatch1 = new Document("$match", new Document("permissionStatus", permissionStatus));
		Bson bsonLookup = new Document("$lookup", new Document("from", "study").append("localField", "studyId")
				.append("foreignField", "studyId").append("as", "study"));
		Bson bsonMatch2 = new Document("$match", new Document("study.userId", loggedInUserId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonMatch1);
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch2);

		List<StudyPermission> list = find(bsonFilterList);

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}