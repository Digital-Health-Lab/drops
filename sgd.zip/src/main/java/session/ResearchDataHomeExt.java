package session;

import com.mongodb.client.model.Filters;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;

import entity.ResearchData;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class ResearchDataHomeExt extends ResearchDataHome {

	private static final Logger LOGGER = Logger.getLogger(ResearchDataHomeExt.class.getName());

	private MyNullChecker myNullChecker = new MyNullChecker();

	public List<ResearchData> queryByResearchData(ResearchData researchData) {
		if (researchData == null) {
			return null;
		}

		List<ResearchData> list = find(Filters.eq("_id", researchData.get_id()));

		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<ResearchData> queryByStudyId(Integer studyId) {
		studyId = myNullChecker.cni(studyId);
		if (studyId == 0) {
			return null;
		}

		List<ResearchData> list = find(Filters.eq("studyId", studyId));
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List<ResearchData> queryByStudyUserId(Integer userId) {
		userId = myNullChecker.cni(userId);
		if (userId == 0) {
			return null;
		}

		Bson bsonLookup = new Document("$lookup", new Document("from", "study").append("localField", "studyId")
				.append("foreignField", "studyId").append("as", "study"));
		Bson bsonMatch = new Document("$match", new Document("study.userId", userId));

		List<Bson> bsonFilterList = new ArrayList<>();
		bsonFilterList.add(bsonLookup);
		bsonFilterList.add(bsonMatch);

		List<ResearchData> list = find(bsonFilterList);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
}