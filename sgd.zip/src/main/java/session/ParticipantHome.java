package session;

import static java.lang.System.out;

import com.mongodb.Block;
import com.mongodb.MongoException;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import database.DatabaseCRUD;
import entity.Participant;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Stateless
public class ParticipantHome {

	private static final Logger LOGGER = Logger.getLogger(ParticipantHome.class.getName());
	private static final String COLLECTION = "participant";

	private DatabaseCRUD dbDAO = null;

	private MyNullChecker myNullChecker = new MyNullChecker();

	private boolean connectCollection() throws MongoException, IOException {
		dbDAO = new DatabaseCRUD();
		dbDAO.openDB();

		if (dbDAO.connectDBCollection(COLLECTION)) {
			return true;
		}

		return false;
	}

	public ObjectId create(Participant participant) {
		try {
			if (connectCollection() && participant != null) {
				Document document = new Document().append("participantId", dbDAO.getTotalCount(null) + 1)
						.append("studyId", participant.getStudyId()).append("age", participant.getAge())
						.append("gender", participant.getGender()).append("postcode", participant.getPostcode())
						.append("variableName", participant.getVariableName())
						.append("variableValue", participant.getVariableValue())
						.append("addData", participant.getAddData()).append("createdAt", new Date())
						.append("updatedAt", new Date());

				dbDAO.insertData(document);

				return document.getObjectId("_id");
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return null;
	}

	public boolean update(Participant participant) {
		try {
			if (connectCollection() && participant != null) {
				Document document = new Document().append("participantId", participant.getParticipantId())
						.append("studyId", participant.getStudyId()).append("age", participant.getAge())
						.append("gender", participant.getGender()).append("postcode", participant.getPostcode())
						.append("variableName", participant.getVariableName())
						.append("variableValue", participant.getVariableValue())
						.append("addData", participant.getAddData()).append("updatedAt", new Date())
						.append("deletedAt", participant.getDeletedAt());

				dbDAO.updateData(new Document("_id", participant.get_id()), document);

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public boolean delete(Participant participant) {
		try {
			if (connectCollection() && participant != null) {
				dbDAO.deleteData(new Document("_id", participant.get_id()));

				return true;
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return false;
	}

	public List<Participant> find(Bson regexQuery) {
		final List<Participant> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				FindIterable<Document> iter = dbDAO.searchData(regexQuery);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					Participant participant = new Participant(document.getObjectId("_id"),
							document.getInteger("participantId"), document.getInteger("studyId"),
							document.getInteger("age"), document.getString("gender"), document.getString("postcode"),
							document.getString("variableName"), document.getString("variableValue"),
							document.getString("addData"), document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(participant);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		if (list.size() == 0) {
			return null;
		}

		return list;
	}

	public List<Participant> find(List<Bson> regexQueryList) {
		final List<Participant> list = new ArrayList<>();

		try {
			if (connectCollection()) {
				AggregateIterable<Document> iter = dbDAO.searchData(regexQueryList);

				iter.forEach((Block<Document>) document -> {
					out.println(document.toJson());

					Participant participant = new Participant(document.getObjectId("_id"),
							document.getInteger("participantId"), document.getInteger("studyId"),
							document.getInteger("age"), document.getString("gender"), document.getString("postcode"),
							document.getString("variableName"), document.getString("variableValue"),
							document.getString("addData"), document.getDate("createdAt"), document.getDate("updatedAt"),
							document.getDate("deletedAt"));
					list.add(participant);
				});
			}
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbDAO.closeDB();
		}

		return list;
	}

	public Participant trimInput(Participant participant) {
		if (participant != null) {
			participant.setAge(myNullChecker.cni(participant.getAge(), null));
			participant.setGender(myNullChecker.cns(participant.getGender(), null));
			participant.setPostcode(myNullChecker.cns(participant.getPostcode(), null));
			participant.setVariableName(myNullChecker.cns(participant.getVariableName(), null));
			participant.setVariableValue(myNullChecker.cns(participant.getVariableValue(), null));
			participant.setAddData(myNullChecker.cns(participant.getAddData(), null));
		}

		return participant;
	}
}