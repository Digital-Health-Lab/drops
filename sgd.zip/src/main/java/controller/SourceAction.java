package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.Source;
import session.SourceHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("sourceAction")
@SessionScoped
public class SourceAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private SourceHomeExt sourceHomeExt;

	private Source source = new Source();
	private List<Source> list = null;
	private Integer sourceIdFilter = null;
	private String nameFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public SourceAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		source = sourceHomeExt.trimInput(source);
		if (sourceHomeExt.create(source) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(Source source) {
		source = sourceHomeExt.trimInput(source);
		if (sourceHomeExt.update(source)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(Source source) {
		if (sourceHomeExt.delete(source)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (sourceIdFilter != null && sourceIdFilter > 0) {
			list = sourceHomeExt.queryBySourceId(sourceIdFilter);
		} else if (!nameFilter.equals("")) {
			list = sourceHomeExt.queryLikeNameIns(nameFilter);
		} else {
			list = sourceHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		sourceIdFilter = null;
		nameFilter = "";
		find();
	}

	public void editThis(Source source) {
		list = sourceHomeExt.queryBySource(source);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public Source getSource() {
		return source;
	}

	public void setSource(Source source) {
		this.source = source;
	}

	public List<Source> getList() {
		return list;
	}

	public void setList(List<Source> list) {
		this.list = list;
	}

	public Integer getSourceIdFilter() {
		return sourceIdFilter;
	}

	public void setSourceIdFilter(Integer sourceIdFilter) {
		this.sourceIdFilter = myNullChecker.cni(sourceIdFilter, null);
	}

	public String getNameFilter() {
		return nameFilter;
	}

	public void setNameFilter(String nameFilter) {
		this.nameFilter = myNullChecker.cns(nameFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}