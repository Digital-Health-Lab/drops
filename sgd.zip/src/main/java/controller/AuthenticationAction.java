package controller;

import static java.lang.System.out;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.commons.validator.routines.EmailValidator;

import constant.Constants;
import entity.User;
import entity.UserProfile;
import security.ClientSession;
import session.UserProfileHomeExt;
import session.UserHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("authenticationAction")
@SessionScoped
public class AuthenticationAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private UserHomeExt userHomeExt;
	@EJB
	private UserProfileHomeExt userProfileHomeExt;

	private String username = "";
	private String password = "";
	private String message = "";

	private ClientSession userSession = new ClientSession();

	private MyNullChecker myNullChecker = new MyNullChecker();

	public AuthenticationAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
	}

	public String authenticate() {
		String returnStr = Constants.LOGIN_FAILURE;
		// Validate Username
		if (username.equals("")) {
			message = "Please enter Username";
			out.println(message);
			return returnStr;
		}
		if (!EmailValidator.getInstance().isValid(username)) {
			message = "Invalid Username";
			out.println(message);
			return returnStr;
		}

		// Validate Password
		if (password.equals("")) {
			message = "Please enter Password";
			out.println(message);
			return returnStr;
		}

		// Validate Username and Password
		List<User> userList = userHomeExt.queryByUsernameAndPassword(username, password);
		if (userList == null) {
			message = "Invalid Username and Passowrd";
			out.println(message);
			return returnStr;
		}

		// Update lastLoginAt in User
		User user = userList.get(0);
		user.setLastLoginAt(new Date());
		userHomeExt.update(user);

		// Set userSession
		userSession.setUserInfo(username, user.getUserId());

		String userName = "";

		// Get user profile
		List<UserProfile> userProfileList = userProfileHomeExt.queryByUserId(user.getUserId());
		if (userProfileList != null) {
			UserProfile userProfile = userProfileList.get(0);
			userSession.setUserName(userProfile.getFirstName(), userProfile.getLastName());
			userName = myNullChecker.cns(userSession.getUserName());
		}

		if (userName.equals("")) {
			userName = user.getUsername();
			returnStr = Constants.LOGIN_SUCCESS;
		} else {
			returnStr = "userProfileCompleted";
		}

		message = "Welcome " + userName;
		out.println(message);

		return returnStr;
	}

	public String logout() {
		userSession.getSession().invalidate();

		message = "You have logged out successfully!";
		out.println(message);

		return Constants.LOGOUT;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = myNullChecker.cns(username).toLowerCase();
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = myNullChecker.cns(password);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}
}