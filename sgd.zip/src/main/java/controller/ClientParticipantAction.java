package controller;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import entity.Participant;
import entity.Study;
import security.ClientSession;
import session.ParticipantHomeExt;
import session.StudyHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientParticipantAction")
@SessionScoped
public class ClientParticipantAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private ParticipantHomeExt participantHomeExt;
	@EJB
	private StudyHomeExt studyHomeExt;

	private Participant participant = new Participant();
	private List<Participant> list = null;
	private List<Study> studyList = null;
	private Integer loggedInUserId = null;
	private Integer urlStudyId = null;
	private Integer studyIdFilter = null;
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ClientParticipantAction() {
	}

	@PostConstruct
	public void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);
		urlStudyId = myNullChecker.cni(userSession.getRequest().getParameter("studyId"), null);

		studyList = studyHomeExt.queryByUserId(loggedInUserId);

		message = "";
		find();
	}

	public void create() {
		participant = participantHomeExt.trimInput(participant);
		if (participantHomeExt.create(participant) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(Participant participant) {
		participant = participantHomeExt.trimInput(participant);
		if (participantHomeExt.update(participant)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(Participant participant) {
		participant.setDeletedAt(new Date());
		update(participant);
	}

	public void find() {
		if (loggedInUserId != null) {
			if (urlStudyId != null) {
				list = participantHomeExt.queryByStudyId(urlStudyId);
			} else {
				if (studyIdFilter != null && studyIdFilter > 0) {
					list = participantHomeExt.queryByStudyId(studyIdFilter, loggedInUserId);
				} else {
					list = participantHomeExt.queryByStudyUserId(loggedInUserId);
				}
			}
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		studyIdFilter = null;
		find();
	}

	public void editThis(Participant participant) {
		list = participantHomeExt.queryByParticipant(participant);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public Participant getParticipant() {
		return participant;
	}

	public void setParticipant(Participant participant) {
		this.participant = participant;
	}

	public List<Participant> getList() {
		return list;
	}

	public void setList(List<Participant> list) {
		this.list = list;
	}

	public List<Study> getStudyList() {
		return studyList;
	}

	public void setStudyList(List<Study> studyList) {
		this.studyList = studyList;
	}

	public Integer getUrlStudyId() {
		return urlStudyId;
	}

	public void setUrlStudyId(Integer urlStudyId) {
		this.urlStudyId = myNullChecker.cni(urlStudyId, null);
	}

	public Integer getStudyIdFilter() {
		return studyIdFilter;
	}

	public void setStudyIdFilter(Integer studyIdFilter) {
		this.studyIdFilter = myNullChecker.cni(studyIdFilter, null);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}