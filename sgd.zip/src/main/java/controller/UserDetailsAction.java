package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.UserDetails;
import session.UserDetailsHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("userDetailsAction")
@SessionScoped
public class UserDetailsAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private UserDetailsHomeExt userDetailsHomeExt;

	private UserDetails userDetails = new UserDetails();
	private List<UserDetails> list = null;
	private String firstNameFilter = "";
	private String lastNameFilter = "";
	private String emailFilter = "";
	private String mobilePhoneFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public UserDetailsAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		userDetails = userDetailsHomeExt.trimInput(userDetails);
		if (userDetailsHomeExt.create(userDetails) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(UserDetails userDetails) {
		userDetails = userDetailsHomeExt.trimInput(userDetails);
		if (userDetailsHomeExt.update(userDetails)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(UserDetails userDetails) {
		if (userDetailsHomeExt.delete(userDetails)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (firstNameFilter.equals("") && lastNameFilter.equals("") && emailFilter.equals("")
				&& mobilePhoneFilter.equals("")) {
			list = userDetailsHomeExt.find(bsonFilter);
		} else {
			list = userDetailsHomeExt.queryLikeUserDetailsIns(firstNameFilter, lastNameFilter, emailFilter,
					mobilePhoneFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		firstNameFilter = "";
		lastNameFilter = "";
		emailFilter = "";
		mobilePhoneFilter = "";
		find();
	}

	public void editThis(UserDetails userDetails) {
		list = userDetailsHomeExt.queryByUserDetails(userDetails);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public List<UserDetails> getList() {
		return list;
	}

	public void setList(List<UserDetails> list) {
		this.list = list;
	}

	public String getFirstNameFilter() {
		return firstNameFilter;
	}

	public void setFirstNameFilter(String firstNameFilter) {
		this.firstNameFilter = myNullChecker.cns(firstNameFilter);
	}

	public String getLastNameFilter() {
		return lastNameFilter;
	}

	public void setLastNameFilter(String lastNameFilter) {
		this.lastNameFilter = myNullChecker.cns(lastNameFilter);
	}

	public String getEmailFilter() {
		return emailFilter;
	}

	public void setEmailFilter(String emailFilter) {
		this.emailFilter = myNullChecker.cns(emailFilter);
	}

	public String getMobilePhoneFilter() {
		return mobilePhoneFilter;
	}

	public void setMobilePhoneFilter(String mobilePhoneFilter) {
		this.mobilePhoneFilter = myNullChecker.cns(mobilePhoneFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}