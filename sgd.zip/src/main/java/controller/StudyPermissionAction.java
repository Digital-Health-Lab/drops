package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.StudyPermission;
import session.StudyPermissionHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("studyPermissionAction")
@SessionScoped
public class StudyPermissionAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StudyPermissionHomeExt studyPermissionHomeExt;

	private StudyPermission studyPermission = new StudyPermission();
	private List<StudyPermission> list = null;
	private Integer studyPermissionIdFilter = null;
	private Integer studyIdFilter = null;
	private Integer studyUserIdFilter = null;
	private Integer userIdFilter = null;
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public StudyPermissionAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		studyPermission = studyPermissionHomeExt.trimInput(studyPermission);
		if (studyPermissionHomeExt.create(studyPermission) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(StudyPermission studyPermission) {
		studyPermission = studyPermissionHomeExt.trimInput(studyPermission);
		if (studyPermissionHomeExt.update(studyPermission)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(StudyPermission studyPermission) {
		if (studyPermissionHomeExt.delete(studyPermission)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (studyPermissionIdFilter != null && studyPermissionIdFilter > 0) {
			list = studyPermissionHomeExt.queryByStudyPermissionId(studyPermissionIdFilter);
		} else if (studyIdFilter != null && studyIdFilter > 0) {
			list = studyPermissionHomeExt.queryByStudyId(studyIdFilter);
		} else if (studyUserIdFilter != null && studyUserIdFilter > 0) {
			list = studyPermissionHomeExt.queryByStudyUserId(studyUserIdFilter);
		} else if (userIdFilter != null && userIdFilter > 0) {
			list = studyPermissionHomeExt.queryByUserId(userIdFilter);
		} else {
			list = studyPermissionHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		studyPermissionIdFilter = null;
		studyIdFilter = null;
		studyUserIdFilter = null;
		userIdFilter = null;
		find();
	}

	public void editThis(StudyPermission studyPermission) {
		list = studyPermissionHomeExt.queryByStudyPermission(studyPermission);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public StudyPermission getStudyPermission() {
		return studyPermission;
	}

	public void setStudyPermission(StudyPermission studyPermission) {
		this.studyPermission = studyPermission;
	}

	public List<StudyPermission> getList() {
		return list;
	}

	public void setList(List<StudyPermission> list) {
		this.list = list;
	}

	public Integer getStudyPermissionIdFilter() {
		return studyPermissionIdFilter;
	}

	public void setStudyPermissionIdFilter(Integer studyPermissionIdFilter) {
		this.studyPermissionIdFilter = myNullChecker.cni(studyPermissionIdFilter, null);
	}

	public Integer getStudyIdFilter() {
		return studyIdFilter;
	}

	public void setStudyIdFilter(Integer studyIdFilter) {
		this.studyIdFilter = myNullChecker.cni(studyIdFilter, null);
	}

	public Integer getStudyUserIdFilter() {
		return studyUserIdFilter;
	}

	public void setStudyUserIdFilter(Integer studyUserIdFilter) {
		this.studyUserIdFilter = myNullChecker.cni(studyUserIdFilter, null);
	}

	public Integer getUserIdFilter() {
		return userIdFilter;
	}

	public void setUserIdFilter(Integer userIdFilter) {
		this.userIdFilter = myNullChecker.cni(userIdFilter, null);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}