package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import org.bson.conversions.Bson;

import entity.UserProfile;
import security.ClientSession;
import session.UserProfileHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("userProfileAction")
@SessionScoped
public class UserProfileAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private UserProfileHomeExt userProfileHomeExt;

	private UserProfile userProfile = new UserProfile();
	private List<UserProfile> list = null;
	private Integer userIdFilter = null;
	private String firstNameFilter = "";
	private String lastNameFilter = "";
	private String emailFilter = "";
	private String mobilePhoneFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public UserProfileAction() {
	}

	@PostConstruct
	private void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		userProfile.setUserId(myNullChecker.cni(httpSession.getAttribute("userId"), null));
		userProfile.setEmail(myNullChecker.cns(httpSession.getAttribute("username"), null));

		message = "";
		find();
	}

	public void create() {
		userProfile = userProfileHomeExt.trimInput(userProfile);
		if (userProfileHomeExt.create(userProfile) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(UserProfile userProfile) {
		userProfile = userProfileHomeExt.trimInput(userProfile);
		if (userProfileHomeExt.update(userProfile)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(UserProfile userProfile) {
		if (userProfileHomeExt.delete(userProfile)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (userIdFilter != null && userIdFilter > 0) {
			list = userProfileHomeExt.queryByUserId(userIdFilter);
		} else if (!firstNameFilter.equals("") || !lastNameFilter.equals("") || !emailFilter.equals("")
				|| !mobilePhoneFilter.equals("")) {
			list = userProfileHomeExt.queryLikeUserProfileIns(firstNameFilter, lastNameFilter, emailFilter,
					mobilePhoneFilter);
		} else {
			list = userProfileHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		userIdFilter = null;
		firstNameFilter = "";
		lastNameFilter = "";
		emailFilter = "";
		mobilePhoneFilter = "";
		find();
	}

	public void editThis(UserProfile userProfile) {
		list = userProfileHomeExt.queryByUserProfile(userProfile);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public List<UserProfile> getList() {
		return list;
	}

	public void setList(List<UserProfile> list) {
		this.list = list;
	}

	public Integer getUserIdFilter() {
		return userIdFilter;
	}

	public void setUserIdFilter(Integer userIdFilter) {
		this.userIdFilter = myNullChecker.cni(userIdFilter, null);
	}

	public String getFirstNameFilter() {
		return firstNameFilter;
	}

	public void setFirstNameFilter(String firstNameFilter) {
		this.firstNameFilter = myNullChecker.cns(firstNameFilter);
	}

	public String getLastNameFilter() {
		return lastNameFilter;
	}

	public void setLastNameFilter(String lastNameFilter) {
		this.lastNameFilter = myNullChecker.cns(lastNameFilter);
	}

	public String getEmailFilter() {
		return emailFilter;
	}

	public void setEmailFilter(String emailFilter) {
		this.emailFilter = myNullChecker.cns(emailFilter);
	}

	public String getMobilePhoneFilter() {
		return mobilePhoneFilter;
	}

	public void setMobilePhoneFilter(String mobilePhoneFilter) {
		this.mobilePhoneFilter = myNullChecker.cns(mobilePhoneFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}