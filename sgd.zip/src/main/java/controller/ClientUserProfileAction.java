package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import entity.UserProfile;
import security.ClientSession;
import session.UserProfileHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientUserProfileAction")
@SessionScoped
public class ClientUserProfileAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private UserProfileHomeExt userProfileHomeExt;

	private UserProfile userProfile = new UserProfile();
	private List<UserProfile> list = null;
	private Integer loggedInUserId = null;
	private String message = "";

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ClientUserProfileAction() {
	}

	@PostConstruct
	private void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);
		list = userProfileHomeExt.queryByUserId(loggedInUserId);

		if (list != null) {
			userProfile = list.get(0);
		} else {
			userProfile.setUserId(loggedInUserId);
			userProfile.setEmail(myNullChecker.cns(httpSession.getAttribute("username"), null));
		}

		message = "";
	}

	public String save() {
		userProfile = userProfileHomeExt.trimInput(userProfile);

		if (loggedInUserId != null) {
			if (userProfileHomeExt.update(userProfile)) {
				message = "Saved successfully.";
			} else {
				message = "Saved failed.";
			}
		} else {
			if (userProfileHomeExt.create(userProfile) != null) {
				message = "Created successfully.";
			} else {
				message = "Created failed.";
			}
		}

		return "saved";
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}
}