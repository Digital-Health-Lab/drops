package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.StepCount;
import session.StepCountHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("stepCountAction")
@SessionScoped
public class StepCountAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StepCountHomeExt stepCountHomeExt;

	private StepCount stepCount = new StepCount();
	private List<StepCount> list = null;
	private Integer participantIdFilter = null;
	private Integer participantStudyIdFilter = null;
	private Integer participantStudyUserIdFilter = null;
	private Integer sourceIdFilter = null;
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public StepCountAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		stepCount = stepCountHomeExt.trimInput(stepCount);
		if (stepCountHomeExt.create(stepCount) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(StepCount stepCount) {
		stepCount = stepCountHomeExt.trimInput(stepCount);
		if (stepCountHomeExt.update(stepCount)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(StepCount stepCount) {
		if (stepCountHomeExt.delete(stepCount)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (participantIdFilter != null && participantIdFilter > 0) {
			list = stepCountHomeExt.queryByParticipantId(participantIdFilter);
		} else if (participantStudyIdFilter != null && participantStudyIdFilter > 0) {
			list = stepCountHomeExt.queryByParticipantStudyId(participantStudyIdFilter);
		} else if (participantStudyUserIdFilter != null && participantStudyUserIdFilter > 0) {
			list = stepCountHomeExt.queryByParticipantStudyUserId(participantStudyUserIdFilter);
		} else if (sourceIdFilter != null && sourceIdFilter > 0) {
			list = stepCountHomeExt.queryBySourceId(sourceIdFilter);
		} else {
			list = stepCountHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		participantIdFilter = null;
		participantStudyIdFilter = null;
		participantStudyUserIdFilter = null;
		sourceIdFilter = null;
		find();
	}

	public void editThis(StepCount stepCount) {
		list = stepCountHomeExt.queryByStepCount(stepCount);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public StepCount getStepCount() {
		return stepCount;
	}

	public void setStepCount(StepCount stepCount) {
		this.stepCount = stepCount;
	}

	public List<StepCount> getList() {
		return list;
	}

	public void setList(List<StepCount> list) {
		this.list = list;
	}

	public Integer getParticipantIdFilter() {
		return participantIdFilter;
	}

	public void setParticipantIdFilter(Integer participantIdFilter) {
		this.participantIdFilter = myNullChecker.cni(participantIdFilter, null);
	}

	public Integer getParticipantStudyIdFilter() {
		return participantStudyIdFilter;
	}

	public void setParticipantStudyIdFilter(Integer participantStudyIdFilter) {
		this.participantStudyIdFilter = myNullChecker.cni(participantStudyIdFilter, null);
	}

	public Integer getParticipantStudyUserIdFilter() {
		return participantStudyUserIdFilter;
	}

	public void setParticipantStudyUserIdFilter(Integer participantStudyUserIdFilter) {
		this.participantStudyUserIdFilter = myNullChecker.cni(participantStudyUserIdFilter, null);
	}

	public Integer getSourceIdFilter() {
		return sourceIdFilter;
	}

	public void setSourceIdFilter(Integer sourceIdFilter) {
		this.sourceIdFilter = myNullChecker.cni(sourceIdFilter, null);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}