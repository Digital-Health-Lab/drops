package controller;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import entity.Participant;
import entity.Source;
import entity.StepCount;
import security.ClientSession;
import session.ParticipantHomeExt;
import session.SourceHomeExt;
import session.StepCountHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientStepCountAction")
@SessionScoped
public class ClientStepCountAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StepCountHomeExt stepCountHomeExt;
	@EJB
	private ParticipantHomeExt participantHomeExt;
	@EJB
	private SourceHomeExt sourceHomeExt;

	private StepCount stepCount = new StepCount();
	private List<StepCount> list = null;
	private List<Participant> participantList = null;
	private List<Source> sourceList = null;
	private Integer loggedInUserId = null;
	private Integer participantStudyIdFilter = null;
	private Integer sourceIdFilter = null;
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ClientStepCountAction() {
	}

	@PostConstruct
	private void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);

		participantList = participantHomeExt.queryByStudyUserId(loggedInUserId);
		sourceList = sourceHomeExt.find(null);

		message = "";
		find();
	}

	public void create() {
		stepCount = stepCountHomeExt.trimInput(stepCount);
		if (stepCountHomeExt.create(stepCount) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(StepCount stepCount) {
		stepCount = stepCountHomeExt.trimInput(stepCount);
		if (stepCountHomeExt.update(stepCount)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(StepCount stepCount) {
		stepCount.setDeletedAt(new Date());
		update(stepCount);
	}

	public void find() {
		if (loggedInUserId != null) {
			if (participantStudyIdFilter != null && participantStudyIdFilter > 0) {
				list = stepCountHomeExt.queryByParticipantStudyId(participantStudyIdFilter, loggedInUserId);
			} else if (sourceIdFilter != null && sourceIdFilter > 0) {
				list = stepCountHomeExt.queryBySourceId(sourceIdFilter, loggedInUserId);
			} else {
				list = stepCountHomeExt.queryByParticipantStudyUserId(loggedInUserId);
			}
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		participantStudyIdFilter = null;
		sourceIdFilter = null;
		find();
	}

	public void editThis(StepCount stepCount) {
		list = stepCountHomeExt.queryByStepCount(stepCount);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public StepCount getStepCount() {
		return stepCount;
	}

	public void setStepCount(StepCount stepCount) {
		this.stepCount = stepCount;
	}

	public List<StepCount> getList() {
		return list;
	}

	public void setList(List<StepCount> list) {
		this.list = list;
	}

	public List<Participant> getParticipantList() {
		return participantList;
	}

	public void setParticipantList(List<Participant> participantList) {
		this.participantList = participantList;
	}

	public List<Source> getSourceList() {
		return sourceList;
	}

	public void setSourceList(List<Source> sourceList) {
		this.sourceList = sourceList;
	}

	public Integer getParticipantStudyIdFilter() {
		return participantStudyIdFilter;
	}

	public void setParticipantStudyIdFilter(Integer participantStudyIdFilter) {
		this.participantStudyIdFilter = myNullChecker.cni(participantStudyIdFilter, null);
	}

	public Integer getSourceIdFilter() {
		return sourceIdFilter;
	}

	public void setSourceIdFilter(Integer sourceIdFilter) {
		this.sourceIdFilter = myNullChecker.cni(sourceIdFilter, null);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}