package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.User;
import session.UserHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("userAction")
@SessionScoped
public class UserAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private UserHomeExt userHomeExt;

	private User user = new User();
	private List<User> list = null;
	private Integer userIdFilter = null;
	private String usernameFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public UserAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		user = userHomeExt.trimInput(user);
		if (userHomeExt.create(user) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(User user) {
		user = userHomeExt.trimInput(user);
		if (userHomeExt.update(user)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(User user) {
		if (userHomeExt.delete(user)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (userIdFilter != null && userIdFilter > 0) {
			list = userHomeExt.queryByUserId(userIdFilter);
		} else if (!usernameFilter.equals("")) {
			list = userHomeExt.queryLikeUsernameIns(usernameFilter);
		} else {
			list = userHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		userIdFilter = null;
		usernameFilter = "";
		find();
	}

	public void editThis(User user) {
		list = userHomeExt.queryByUser(user);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<User> getList() {
		return list;
	}

	public void setList(List<User> list) {
		this.list = list;
	}

	public Integer getUserIdFilter() {
		return userIdFilter;
	}

	public void setUserIdFilter(Integer userIdFilter) {
		this.userIdFilter = myNullChecker.cni(userIdFilter, null);
	}

	public String getUsernameFilter() {
		return usernameFilter;
	}

	public void setUsernameFilter(String usernameFilter) {
		this.usernameFilter = myNullChecker.cns(usernameFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}