package controller;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import entity.Study;
import security.ClientSession;
import session.StudyHomeExt;
import session.UserHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientStudyAction")
@SessionScoped
public class ClientStudyAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StudyHomeExt studyHomeExt;
	@EJB
	private UserHomeExt userHomeExt;

	private Study study = new Study();
	private List<Study> list = null;
	private List<Study> studyList = null;
	private Integer loggedInUserId = null;
	private Integer parentStudyIdFilter = null;
	private String keywordsFilter = "";
	private String message = "";
	private boolean editable = false;
	private boolean viewOthers = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ClientStudyAction() {
	}

	@PostConstruct
	private void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);
		study.setUserId(loggedInUserId);
		study.setFileType("csv");

		studyList = studyHomeExt.queryByUserId(loggedInUserId);

		message = "";
		find();
	}

	public void create() {
		study = studyHomeExt.trimInput(study);
		if (studyHomeExt.create(study) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(Study study) {
		study = studyHomeExt.trimInput(study);
		if (studyHomeExt.update(study)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(Study study) {
		study.setDeletedAt(new Date());
		update(study);
	}

	public void find() {
		if (loggedInUserId != null) {
			if (!viewOthers) {
				if (parentStudyIdFilter != null && parentStudyIdFilter > 0) {
					list = studyHomeExt.queryByParentStudyId(parentStudyIdFilter, loggedInUserId);
				} else if (!keywordsFilter.equals("")) {
					list = studyHomeExt.queryLikeKeywordsIns(keywordsFilter, loggedInUserId);
				} else {
					list = studyHomeExt.queryByUserId(loggedInUserId);
				}
			} else {
				list = studyHomeExt.lookUpSharedfromOthers(loggedInUserId);
			}
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		parentStudyIdFilter = null;
		keywordsFilter = "";
		find();
	}

	public void editThis(Study study) {
		list = studyHomeExt.queryByStudy(study);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public Study getStudy() {
		return study;
	}

	public void setStudy(Study study) {
		this.study = study;
	}

	public List<Study> getList() {
		return list;
	}

	public void setList(List<Study> list) {
		this.list = list;
	}

	public List<Study> getStudyList() {
		return studyList;
	}

	public void setStudyList(List<Study> studyList) {
		this.studyList = studyList;
	}

	public Integer getParentStudyIdFilter() {
		return parentStudyIdFilter;
	}

	public void setParentStudyIdFilter(Integer parentStudyIdFilter) {
		this.parentStudyIdFilter = myNullChecker.cni(parentStudyIdFilter, null);
	}

	public String getKeywordsFilter() {
		return keywordsFilter;
	}

	public void setKeywordsFilter(String keywordsFilter) {
		this.keywordsFilter = myNullChecker.cns(keywordsFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public boolean isViewOthers() {
		return viewOthers;
	}

	public void setViewOthers(boolean viewOthers) {
		this.viewOthers = viewOthers;
		find();
	}
}