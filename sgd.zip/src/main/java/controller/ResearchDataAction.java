package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.ResearchData;
import session.ResearchDataHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("researchDataAction")
@SessionScoped
public class ResearchDataAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private ResearchDataHomeExt researchDataHomeExt;

	private ResearchData researchData = new ResearchData();
	private List<ResearchData> list = null;
	private Integer studyIdFilter = null;
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ResearchDataAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		researchData = researchDataHomeExt.trimInput(researchData);
		if (researchDataHomeExt.create(researchData) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(ResearchData researchData) {
		if (researchDataHomeExt.update(researchData)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(ResearchData researchData) {
		if (researchDataHomeExt.delete(researchData)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (studyIdFilter == null || studyIdFilter <= 0) {
			list = researchDataHomeExt.find(bsonFilter);
		} else {
			list = researchDataHomeExt.queryByStudyId(studyIdFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		studyIdFilter = null;
		find();
	}

	public void editThis(ResearchData researchData) {
		list = researchDataHomeExt.queryByResearchData(researchData);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public ResearchData getResearchData() {
		return researchData;
	}

	public void setResearchData(ResearchData researchData) {
		this.researchData = researchData;
	}

	public List<ResearchData> getList() {
		return list;
	}

	public void setList(List<ResearchData> list) {
		this.list = list;
	}

	public Integer getStudyIdFilter() {
		return studyIdFilter;
	}

	public void setStudyIdFilter(Integer studyIdFilter) {
		this.studyIdFilter = myNullChecker.cni(studyIdFilter, null);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}