package controller;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import entity.StudyPermission;
import security.ClientSession;
import session.StudyPermissionHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientStudyPermissionAction")
@SessionScoped
public class ClientStudyPermissionAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StudyPermissionHomeExt studyPermissionHomeExt;

	private StudyPermission studyPermission = new StudyPermission();
	private List<StudyPermission> list = null;
	private Integer loggedInUserId = null;
	private Integer studyIdFilter = null;
	private String permissionStatusFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ClientStudyPermissionAction() {
	}

	@PostConstruct
	private void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);

		message = "";
		find();
	}

	public void update(StudyPermission studyPermission) {
		studyPermission = studyPermissionHomeExt.trimInput(studyPermission);
		if (studyPermissionHomeExt.update(studyPermission)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(StudyPermission studyPermission) {
		studyPermission.setDeletedAt(new Date());
		update(studyPermission);
	}

	public void find() {
		if (loggedInUserId != null) {
			if (studyIdFilter != null && studyIdFilter > 0) {
				list = studyPermissionHomeExt.queryByStudyId(studyIdFilter, loggedInUserId);
			} else if (!permissionStatusFilter.equals("")) {
				list = studyPermissionHomeExt.queryLikePermissionStatusIns(permissionStatusFilter, loggedInUserId);
			} else {
				list = studyPermissionHomeExt.queryByStudyUserId(loggedInUserId);
			}
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		studyIdFilter = null;
		permissionStatusFilter = "";
		find();
	}

	public void editThis(StudyPermission studyPermission) {
		list = studyPermissionHomeExt.queryByStudyPermission(studyPermission);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public StudyPermission getStudyPermission() {
		return studyPermission;
	}

	public void setStudyPermission(StudyPermission studyPermission) {
		this.studyPermission = studyPermission;
	}

	public List<StudyPermission> getList() {
		return list;
	}

	public void setList(List<StudyPermission> list) {
		this.list = list;
	}

	public Integer getStudyIdFilter() {
		return studyIdFilter;
	}

	public void setStudyIdFilter(Integer studyIdFilter) {
		this.studyIdFilter = myNullChecker.cni(studyIdFilter, null);
	}

	public String getPermissionStatusFilter() {
		return permissionStatusFilter;
	}

	public void setPermissionStatusFilter(String permissionStatusFilter) {
		this.permissionStatusFilter = myNullChecker.cns(permissionStatusFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}