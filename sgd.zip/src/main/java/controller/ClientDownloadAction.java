package controller;

import static java.lang.System.out;

import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.opencsv.CSVWriter;

import entity.Participant;
import entity.StepCount;
import entity.Study;
import security.ClientSession;
import session.ParticipantHomeExt;
import session.StepCountHomeExt;
import session.StudyHomeExt;
import util.MyDateTime;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientDownloadAction")
@SessionScoped
public class ClientDownloadAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final int STRING_BUFFER_SIZE = 128;
	private static final String FILE_NAME = "My_data";
	private static final String FILE_EXTENSION_CSV = ".csv";
	private static final String FILE_EXTENSION_ZIP = ".zip";

	@EJB
	private StudyHomeExt studyHomeExt;
	@EJB
	private ParticipantHomeExt participantHomeExt;
	@EJB
	private StepCountHomeExt stepCountHomeExt;

	private ClientSession userSession = new ClientSession();
	private List<Study> studyList = null;
	private List<Participant> participantList = null;
	private List<StepCount> stepCountList = null;

	private Integer loggedInUserId = null;
	private Integer localTimezone;

	private Map<String, List<String[]>> resultMap = new HashMap<String, List<String[]>>();

	private StringBuffer msgSB = new StringBuffer(STRING_BUFFER_SIZE);
	private String message = "";

	private MyNullChecker myNullChecker = new MyNullChecker();
	private MyDateTime myDateTime = new MyDateTime();

	public ClientDownloadAction() {
	}

	@PostConstruct
	private void init() {
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);

		message = "";
	}

	public void studyExport(Study study) {
		msgSB = new StringBuffer(STRING_BUFFER_SIZE);

		if (loggedInUserId != null && study != null && study.getStudyId() != null) {
			studyList = studyHomeExt.queryByStudy(study);
			participantList = participantHomeExt.queryByStudyId(study.getStudyId());
			stepCountList = stepCountHomeExt.queryByParticipantStudyId(study.getStudyId());

			generateStudyCsvFile();
			generateParticipantCsvFile();
			generateStepCountCsvFile();
			downloadFile();
		} else {
			msgSB.append("Please login in first.<br />");
		}

		message = msgSB.toString();
	}

	public void participantExport(Participant participant) {
		msgSB = new StringBuffer(STRING_BUFFER_SIZE);

		if (loggedInUserId != null && participant != null && participant.getParticipantId() != null) {
			participantList = participantHomeExt.queryByParticipant(participant);
			stepCountList = stepCountHomeExt.queryByParticipantId(participant.getParticipantId());

			generateParticipantCsvFile();
			generateStepCountCsvFile();
			downloadFile();
		} else {
			msgSB.append("Please login in first.<br />");
		}

		message = msgSB.toString();
	}

	private void generateStudyCsvFile() {
		if (studyList != null) {
			msgSB.append(studyList.size()).append(" study/s found.<br />");
			List<String[]> strArrList = new ArrayList<String[]>();

			try {
				for (Study document : studyList) {
					String createdAtStr = "";
					String updatedAtStr = "";
					String deletedAtStr = "";
					if (document.getCreatedAt() != null) {
						createdAtStr = myDateTime.getAusDateTime(document.getCreatedAt());
					}
					if (document.getUpdatedAt() != null) {
						updatedAtStr = myDateTime.getAusDateTime(document.getUpdatedAt());
					}
					if (document.getDeletedAt() != null) {
						deletedAtStr = myDateTime.getAusDateTime(document.getDeletedAt());
					}

					if (strArrList.size() == 0) {
						strArrList.add(document.fieldNames);
					}

					String[] strArr = { myNullChecker.cns(document.getStudyId()),
							myNullChecker.cns(document.getUserId()), myNullChecker.cns(document.getParentStudyId()),
							myNullChecker.cns(document.getTitle()), myNullChecker.cns(document.getDescription()),
							myNullChecker.cns(document.getCatgeories()), myNullChecker.cns(document.getKeywords()),
							myNullChecker.cns(document.getFileType()), myNullChecker.cns(document.getContributors()),
							myNullChecker.cns(document.getReferences()), myNullChecker.cns(document.getFunding()),
							myNullChecker.cns(document.getLicence()), myNullChecker.cns(document.getVariableName()),
							myNullChecker.cns(document.getVariableValue()), myNullChecker.cns(document.getAddData()),
							createdAtStr, updatedAtStr, deletedAtStr };
					strArrList.add(strArr);
				}

				resultMap.put("Study", strArrList);
				msgSB.append("Successfully generated study csv file.<br />");
			} catch (Exception e) {
				out.println(getClass() + " generateStudyCsvFile ERROR - " + e.toString());
				msgSB.append("Failed to generate study csv file.<br />");
			}
		} else {
			msgSB.append("No study found.<br />");
		}
	}

	private void generateParticipantCsvFile() {
		if (participantList != null) {
			msgSB.append(participantList.size()).append(" participant/s found.<br />");
			List<String[]> strArrList = new ArrayList<String[]>();

			try {
				for (Participant document : participantList) {
					String createdAtStr = "";
					String updatedAtStr = "";
					String deletedAtStr = "";
					if (document.getCreatedAt() != null) {
						createdAtStr = myDateTime.getAusDateTime(document.getCreatedAt());
					}
					if (document.getUpdatedAt() != null) {
						updatedAtStr = myDateTime.getAusDateTime(document.getUpdatedAt());
					}
					if (document.getDeletedAt() != null) {
						deletedAtStr = myDateTime.getAusDateTime(document.getDeletedAt());
					}

					if (strArrList.size() == 0) {
						strArrList.add(document.fieldNames);
					}

					String[] strArr = { myNullChecker.cns(document.getParticipantId()),
							myNullChecker.cns(document.getStudyId()), myNullChecker.cns(document.getAge()),
							myNullChecker.cns(document.getGender()), myNullChecker.cns(document.getPostcode()),
							myNullChecker.cns(document.getVariableName()),
							myNullChecker.cns(document.getVariableValue()), myNullChecker.cns(document.getAddData()),
							createdAtStr, updatedAtStr, deletedAtStr };
					strArrList.add(strArr);
				}

				resultMap.put("Participant", strArrList);
				msgSB.append("Successfully generated participant csv file.<br />");
			} catch (Exception e) {
				out.println(getClass() + " generateParticipantCsvFile ERROR - " + e.toString());
				msgSB.append("Failed to generate participant csv file.<br />");
			}
		} else {
			msgSB.append("No participant found.<br />");
		}
	}

	private void generateStepCountCsvFile() {
		if (stepCountList != null) {
			msgSB.append(stepCountList.size()).append(" step count/s found.<br />");
			List<String[]> strArrList = new ArrayList<String[]>();

			try {
				for (StepCount document : stepCountList) {
					String measuredAtStr = "";
					String createdAtStr = "";
					String updatedAtStr = "";
					String deletedAtStr = "";
					if (document.getMeasuredAt() != null) {
						measuredAtStr = myDateTime.getAusDateTime(document.getMeasuredAt());
					}
					if (document.getCreatedAt() != null) {
						createdAtStr = myDateTime.getAusDateTime(document.getCreatedAt());
					}
					if (document.getUpdatedAt() != null) {
						updatedAtStr = myDateTime.getAusDateTime(document.getUpdatedAt());
					}
					if (document.getDeletedAt() != null) {
						deletedAtStr = myDateTime.getAusDateTime(document.getDeletedAt());
					}

					if (strArrList.size() == 0) {
						strArrList.add(document.fieldNames);
					}

					String[] strArr = { myNullChecker.cns(document.getParticipantId()),
							myNullChecker.cns(document.getSourceId()), measuredAtStr,
							myNullChecker.cns(document.getDuration()), myNullChecker.cns(document.getSteps()),
							myNullChecker.cns(document.getXAxis()), myNullChecker.cns(document.getYAxis()),
							myNullChecker.cns(document.getZAxis()), myNullChecker.cns(document.getVariableName()),
							myNullChecker.cns(document.getVariableValue()), myNullChecker.cns(document.getAddData()),
							createdAtStr, updatedAtStr, deletedAtStr };
					strArrList.add(strArr);
				}

				resultMap.put("Step-count", strArrList);
				msgSB.append("Successfully generated step count csv file.<br />");
			} catch (Exception e) {
				out.println(getClass() + " generateStepCountCsvFile ERROR - " + e.toString());
				msgSB.append("Failed to generate step count csv file.<br />");
			}
		} else {
			msgSB.append("No step count found.<br />");
		}
	}

	// Export database data or string directly to InputStream for user download.
	private void downloadFile() {
		HttpServletResponse httpServletResponse = userSession.getResponse();
		ServletOutputStream servletOutputStream = null;

		// Some JSF component library or some Filter might have set some
		// headers in the buffer beforehand. We want to get rid of them,
		// else it may collide.
		httpServletResponse.reset();
		// Tell browser program going to return an application file instead
		// of html page.
		httpServletResponse.setContentType("application/zip");
		httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" + FILE_NAME + FILE_EXTENSION_ZIP);

		try {
			// Retrieve OutputStream from HttpServletResponse.
			servletOutputStream = httpServletResponse.getOutputStream();
			// Create a ZipOutputStream from servletOutputStream.
			ZipOutputStream zos = new ZipOutputStream(servletOutputStream);

			Iterator<Map.Entry<String, List<String[]>>> iterator = resultMap.entrySet().iterator();
			while (iterator.hasNext()) {
				Map.Entry<String, List<String[]>> entry = iterator.next();

				// Create a zip entry and add it to ZipOutputStream.
				// A ZipEntry represents a file entry in the zip archive.
				ZipEntry ze = new ZipEntry(entry.getKey() + FILE_EXTENSION_CSV);
				zos.putNextEntry(ze);

				for (String[] line : entry.getValue()) {
					// There is no need for staging the CSV on filesystem
					// or reading bytes into memory.
					CSVWriter writer = new CSVWriter(new OutputStreamWriter(zos));
					// write the contents
					writer.writeNext(line);
					// flush the writer. Very important!
					writer.flush();
				}

				// Right way to remove entries from Map
				// Avoids ConcurrentModificationException
				iterator.remove();

				// Close the entry.
				// Not closing the zos just yet as more files need to be added.
				zos.closeEntry();
			}

			// Finally closing the ZipOutputStream to
			// mark completion of ZIP file.
			zos.close();

			servletOutputStream.flush();
			servletOutputStream.close();

			msgSB.append("Successfully exported data.<br />");
		} catch (Exception e) {
			out.println(getClass() + " downloadFile ERROR - " + e.toString());
			msgSB.append("Failed to export data.<br />");
		} finally {
			if (servletOutputStream != null) {
				try {
					servletOutputStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		userSession.closeResponse(); // Important!
	}

	public Integer getLocalTimezone() {
		return this.localTimezone;
	}

	public void setLocalTimezone(Integer localTimezone) {
		this.localTimezone = localTimezone;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}
}