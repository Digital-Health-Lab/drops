package controller;

import static java.lang.System.out;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import org.apache.commons.io.FilenameUtils;
import com.opencsv.CSVReader;

import entity.Source;
import entity.StepCount;
import security.ClientSession;
import session.ParticipantHomeExt;
import session.SourceHomeExt;
import session.StepCountHomeExt;
import util.MyDateTime;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("clientUploadAction")
@SessionScoped
public class ClientUploadAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String FOLDER_LOCALHOST = "C:/Users/Moroker/Desktop";
	private static final String FOLDER_SERVER = "/home/ec2-user/uploads";
	private static final String TIMESTAMP_FORMAT = "dd/MM/yyyy HH:mm:ss";
	private static final String TIMESTAMP_FORMAT_NO_SECOND = "dd/MM/yyyy HH:mm";
	private static final String TIMESTAMP_FORMAT_NO_TIME = "dd/MM/yyyy";
	private static final int STRING_BUFFER_SIZE = 128;
	private static final String ENCODE = "UTF-8";

	@EJB
	private StepCountHomeExt stepCountHomeExt;
	@EJB
	private ParticipantHomeExt participantHomeExt;
	@EJB
	private SourceHomeExt sourceHomeExt;

	private List<Source> sourceList = null;
	private Integer loggedInUserId = null;
	private Integer urlStudyId = null;
	private Integer urlParticipantId = null;
	private String serverName = "";
	private Integer sourceId = null;
	private Integer duration = null;
	private Part fileToUpload;
	private String message = "";

	private MyNullChecker myNullChecker = new MyNullChecker();
	private MyDateTime myDateTime = new MyDateTime();

	public ClientUploadAction() {
	}

	@PostConstruct
	public void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		loggedInUserId = myNullChecker.cni(httpSession.getAttribute("userId"), null);
		urlStudyId = myNullChecker.cni(userSession.getRequest().getParameter("studyId"), null);
		urlParticipantId = myNullChecker.cni(userSession.getRequest().getParameter("participantId"), null);
		if (userSession.getServerName().indexOf("localhost") != -1) {
			serverName = FOLDER_LOCALHOST;
		} else {
			serverName = FOLDER_SERVER;
		}

		sourceList = sourceHomeExt.find(null);

		message = "";
	}

	public void upload() {
		try (InputStream input = fileToUpload.getInputStream()) {
			Path folder = Paths.get(serverName);
			String fileName = FilenameUtils.getBaseName(fileToUpload.getSubmittedFileName());
			String extension = FilenameUtils.getExtension(fileToUpload.getSubmittedFileName());
			Path file = Files.createTempFile(folder, fileName + "-", "." + extension);

			// Files.copy(input, new File(FOLDER, "hehe.csv").toPath());
			Files.copy(input, file, StandardCopyOption.REPLACE_EXISTING);

			message = "Successfully uploaded.";

			importCsv(file);
		} catch (IOException e) {
			out.println(getClass() + " upload ERROR - " + e.toString());
			message = "Failed to upload.";
		}
	}

	private void importCsv(Path file) {
		try (InputStream input = new FileInputStream(file.toFile())) {
			CSVReader reader = new CSVReader(new InputStreamReader(input, ENCODE));

			StepCount sc = null;
			Integer timestampIndex = null;
			Integer durationIndex = null;
			Integer stepsIndex = null;
			Integer xAxisIndex = null;
			Integer yAxisIndex = null;
			Integer zAxisIndex = null;
			Integer variableNameIndex = null;
			Integer variableValueIndex = null;
			List<String> addDataLabelList = new ArrayList<String>();
			List<Integer> addDataIndexList = new ArrayList<Integer>();

			String[] line;
			int j = 0;
			while ((line = reader.readNext()) != null) {
				if (j == 0) {
					for (int i = 0; i < line.length; i++) {
						String labelStr = myNullChecker.cns(line[i]).toLowerCase();
						if (labelStr.indexOf("timestamp") != -1) {
							timestampIndex = i;
						} else if (labelStr.equals("duration")) {
							durationIndex = i;
						} else if (labelStr.equals("steps") || labelStr.equals("step")) {
							stepsIndex = i;
						} else if (labelStr.equals("xaxis")) {
							xAxisIndex = i;
						} else if (labelStr.equals("yaxis")) {
							yAxisIndex = i;
						} else if (labelStr.equals("zaxis")) {
							zAxisIndex = i;
						} else if (labelStr.equals("variablename")) {
							variableNameIndex = i;
						} else if (labelStr.equals("variablevalue")) {
							variableValueIndex = i;
						} else {
							addDataLabelList.add(myNullChecker.cns(line[i]).replaceAll(",", ";"));
							addDataIndexList.add(i);
						}
					}
				} else {
					sc = new StepCount();
					sc.setParticipantId(urlParticipantId);
					sc.setSourceId(sourceId);

					if (timestampIndex != null) {
						try {
							sc.setMeasuredAt(myDateTime.getDateFromString(line[timestampIndex], TIMESTAMP_FORMAT));
						} catch (Exception e1) {
							try {
								sc.setMeasuredAt(
										myDateTime.getDateFromString(line[timestampIndex], TIMESTAMP_FORMAT_NO_SECOND));
							} catch (Exception e2) {
								sc.setMeasuredAt(
										myDateTime.getDateFromString(line[timestampIndex], TIMESTAMP_FORMAT_NO_TIME));
							}
						}
					}
					if (durationIndex != null) {
						sc.setDuration(myNullChecker.cni(line[durationIndex], null));
					}
					if (stepsIndex != null) {
						sc.setSteps(myNullChecker.cni(line[stepsIndex], null));
					}
					if (xAxisIndex != null) {
						sc.setXAxis(myNullChecker.cnd(line[xAxisIndex], null));
					}
					if (yAxisIndex != null) {
						sc.setYAxis(myNullChecker.cnd(line[yAxisIndex], null));
					}
					if (zAxisIndex != null) {
						sc.setZAxis(myNullChecker.cnd(line[zAxisIndex], null));
					}
					if (variableNameIndex != null) {
						sc.setVariableName(myNullChecker.cns(line[variableNameIndex], null));
					}
					if (variableValueIndex != null) {
						sc.setVariableValue(myNullChecker.cns(line[variableValueIndex], null));
					}

					if (sc.getDuration() == null) {
						sc.setDuration(duration);
					}

					StringBuffer addDataSB = new StringBuffer(STRING_BUFFER_SIZE);
					for (int k = 0; k < addDataLabelList.size(); k++) {
						if (k == 0) {
							addDataSB.append("{");
						}
						addDataSB.append("\"");
						addDataSB.append(addDataLabelList.get(k));
						addDataSB.append("\"");
						addDataSB.append(":");
						addDataSB.append("\"");
						addDataSB.append(line[addDataIndexList.get(k)].replaceAll(",", ""));
						addDataSB.append("\"");

						if (k < addDataLabelList.size() - 1) {
							addDataSB.append(";");
						} else {
							addDataSB.append("}");
						}
					}
					if (addDataSB.length() > 0) {
						sc.setAddData(addDataSB.toString());
					}
				}

				create(sc);

				j++;
			}

			message = "Successfully imported.";
		} catch (IOException ioe) {
			out.println(getClass() + " importCsv IO ERROR - " + ioe.toString());
			message = "Failed to import.";
		} catch (Exception e) {
			out.println(getClass() + " importCsv E ERROR - " + e.toString());
			message = "Failed to import.";
		}
	}

	private void create(StepCount stepCount) {
		stepCount = stepCountHomeExt.trimInput(stepCount);
		if (stepCountHomeExt.create(stepCount) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
	}

	public void update(StepCount stepCount) {
		stepCount = stepCountHomeExt.trimInput(stepCount);
		if (stepCountHomeExt.update(stepCount)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
	}

	public List<Source> getSourceList() {
		return sourceList;
	}

	public void setSourceList(List<Source> sourceList) {
		this.sourceList = sourceList;
	}

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = myNullChecker.cni(sourceId, null);
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = myNullChecker.cni(duration, null);
	}

	public Integer getUrlStudyId() {
		return urlStudyId;
	}

	public void setUrlStudyId(Integer urlStudyId) {
		this.urlStudyId = myNullChecker.cni(urlStudyId, null);
	}

	public Part getFileToUpload() {
		return fileToUpload;
	}

	public void setFileToUpload(Part fileToUpload) {
		this.fileToUpload = fileToUpload;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}
}