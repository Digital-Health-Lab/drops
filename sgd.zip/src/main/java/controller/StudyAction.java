package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import org.bson.conversions.Bson;

import entity.Study;
import security.ClientSession;
import session.StudyHomeExt;
import session.UserHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("studyAction")
@SessionScoped
public class StudyAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private StudyHomeExt studyHomeExt;
	@EJB
	private UserHomeExt userHomeExt;

	private Study study = new Study();
	private List<Study> list = null;
	private Integer studyIdFilter = null;
	private Integer userIdFilter = null;
	private Integer parentStudyIdFilter = null;
	private String keywordsFilter = "";
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public StudyAction() {
	}

	@PostConstruct
	private void init() {
		ClientSession userSession = new ClientSession();
		HttpSession httpSession = userSession.getSession();
		study.setUserId(myNullChecker.cni(httpSession.getAttribute("userId"), null));

		message = "";
		find();
	}

	public void create() {
		study = studyHomeExt.trimInput(study);
		if (studyHomeExt.create(study) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(Study study) {
		study = studyHomeExt.trimInput(study);
		if (studyHomeExt.update(study)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(Study study) {
		if (studyHomeExt.delete(study)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (studyIdFilter != null && studyIdFilter > 0) {
			list = studyHomeExt.queryByStudyId(studyIdFilter);
		} else if (userIdFilter != null && userIdFilter > 0) {
			list = studyHomeExt.queryByUserId(userIdFilter);
		} else if (parentStudyIdFilter != null && parentStudyIdFilter > 0) {
			list = studyHomeExt.queryByParentStudyId(parentStudyIdFilter);
		} else if (!keywordsFilter.equals("")) {
			list = studyHomeExt.queryLikeKeywordsIns(keywordsFilter);
		} else {
			list = studyHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		studyIdFilter = null;
		userIdFilter = null;
		parentStudyIdFilter = null;
		keywordsFilter = "";
		find();
	}

	public void editThis(Study study) {
		list = studyHomeExt.queryByStudy(study);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public Study getStudy() {
		return study;
	}

	public void setStudy(Study study) {
		this.study = study;
	}

	public List<Study> getList() {
		return list;
	}

	public void setList(List<Study> list) {
		this.list = list;
	}

	public Integer getStudyIdFilter() {
		return studyIdFilter;
	}

	public void setStudyIdFilter(Integer studyIdFilter) {
		this.studyIdFilter = myNullChecker.cni(studyIdFilter, null);
	}

	public Integer getUserIdFilter() {
		return userIdFilter;
	}

	public void setUserIdFilter(Integer userIdFilter) {
		this.userIdFilter = myNullChecker.cni(userIdFilter, null);
	}

	public Integer getParentStudyIdFilter() {
		return parentStudyIdFilter;
	}

	public void setParentStudyIdFilter(Integer parentStudyIdFilter) {
		this.parentStudyIdFilter = myNullChecker.cni(parentStudyIdFilter, null);
	}

	public String getKeywordsFilter() {
		return keywordsFilter;
	}

	public void setKeywordsFilter(String keywordsFilter) {
		this.keywordsFilter = myNullChecker.cns(keywordsFilter);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}