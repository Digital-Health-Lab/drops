package controller;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.bson.conversions.Bson;

import entity.Participant;
import session.ParticipantHomeExt;
import util.MyNullChecker;

/**
 *
 * @author Moroker
 *
 */

@Named("participantAction")
@SessionScoped
public class ParticipantAction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
	private ParticipantHomeExt participantHomeExt;

	private Participant participant = new Participant();
	private List<Participant> list = null;
	private Integer participantIdFilter = null;
	private Integer studyIdFilter = null;
	private Integer studyUserIdFilter = null;
	private String message = "";
	private boolean editable = false;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public ParticipantAction() {
	}

	@PostConstruct
	private void init() {
		message = "";
		find();
	}

	public void create() {
		participant = participantHomeExt.trimInput(participant);
		if (participantHomeExt.create(participant) != null) {
			message = "Created successfully.";
		} else {
			message = "Creation failed.";
		}
		find();
	}

	public void update(Participant participant) {
		participant = participantHomeExt.trimInput(participant);
		if (participantHomeExt.update(participant)) {
			message = "Updated successfully.";
		} else {
			message = "Update failed.";
		}
		find();
		editable = false;
	}

	public void delete(Participant participant) {
		if (participantHomeExt.delete(participant)) {
			message = "Deleted successfully.";
		} else {
			message = "Deletion failed.";
		}
		find();
	}

	public void find() {
		Bson bsonFilter = null;
		if (participantIdFilter != null && participantIdFilter > 0) {
			list = participantHomeExt.queryByParticipantId(participantIdFilter);
		} else if (studyIdFilter != null && studyIdFilter > 0) {
			list = participantHomeExt.queryByStudyId(studyIdFilter);
		} else if (studyUserIdFilter != null && studyUserIdFilter > 0) {
			list = participantHomeExt.queryByStudyUserId(studyUserIdFilter);
		} else {
			list = participantHomeExt.find(bsonFilter);
		}

		if (list != null) {
			message = "Found " + list.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}
	}

	public void clearFilter() {
		participantIdFilter = null;
		studyIdFilter = null;
		studyUserIdFilter = null;
		find();
	}

	public void editThis(Participant participant) {
		list = participantHomeExt.queryByParticipant(participant);
		editable = true;
	}

	public void cancelEdit() {
		find();
		editable = false;
	}

	public Participant getParticipant() {
		return participant;
	}

	public void setParticipant(Participant participant) {
		this.participant = participant;
	}

	public List<Participant> getList() {
		return list;
	}

	public void setList(List<Participant> list) {
		this.list = list;
	}

	public Integer getParticipantIdFilter() {
		return participantIdFilter;
	}

	public void setParticipantIdFilter(Integer participantIdFilter) {
		this.participantIdFilter = myNullChecker.cni(participantIdFilter, null);
	}

	public Integer getStudyIdFilter() {
		return studyIdFilter;
	}

	public void setStudyIdFilter(Integer studyIdFilter) {
		this.studyIdFilter = myNullChecker.cni(studyIdFilter, null);
	}

	public Integer getStudyUserIdFilter() {
		return studyUserIdFilter;
	}

	public void setStudyUserIdFilter(Integer studyUserIdFilter) {
		this.studyUserIdFilter = myNullChecker.cni(studyUserIdFilter, null);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = myNullChecker.cns(message);
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}