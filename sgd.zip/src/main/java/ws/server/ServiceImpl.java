package ws.server;

import static java.lang.System.out;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.bson.types.ObjectId;

import entity.ResearchData;
import entity.UserProfile;
import session.ResearchDataHomeExt;
import session.UserProfileHomeExt;
import util.MyNullChecker;
import ws.model.GenericResponse;

/**
 *
 * @author Moroker
 *
 */

@Path("/v1")
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public class ServiceImpl implements ServiceInterface {

	@EJB
	private UserProfileHomeExt userProfileHomeExt;
	@EJB
	private ResearchDataHomeExt researchDataHomeExt;

	private List<UserProfile> userProfileList;
	private List<ResearchData> researchDataList;
	private Status resStatus;
	private GenericResponse response;

	private ObjectMapper mapper = new ObjectMapper();
	private String message = "";

	private MyNullChecker myNullChecker = new MyNullChecker();

	@Override
	public Response index() {
		return Response.status(Status.OK)
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Credentials", "true")
				.entity(Status.OK).build();
	}

	@Override
	public Response printMessage(@PathParam("param") String msg) {
		String result = "Hello : " + msg;

		return Response.status(Status.OK).entity(result).build();
	}

	@Override
	public List<UserProfile> listUserProfile() {
		out.println("*** Calling listusers @GET ***");

		userProfileList = userProfileHomeExt.find(null);
		if (userProfileList != null) {
			message = "Found " + userProfileList.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}

		out.println(message);
		return userProfileList;
	}

	@Override
	public List<UserProfile> getUserProfileByUserId(@QueryParam("userId") Integer userId) {
		out.println("*** Calling getuser for a given userId @GET ***");
		out.println("userId = " + userId);

		if (userId == null) {
			message = "Empty parameter.";
			out.println(message);
			return null;
		} else if (myNullChecker.cni(userId) == 0) {
			message = "Invalid userId.";
			out.println(message);
			return null;
		}

		userProfileList = userProfileHomeExt.queryByUserId(userId);
		if (userProfileList != null) {
			message = "Found " + userProfileList.size() + " record/s.";
			out.println(message);
			return userProfileList;
		} else {
			message = "No records Exist.";
			out.println(message);
			return null;
		}
	}

	@Override
	public Response addUserProfile(UserProfile userProfile) {
		out.println("*** Calling adduser @POST ***");
		try {
			out.println("userProfile in json = " + mapper.writeValueAsString(userProfile));
		} catch (JsonProcessingException e) {
			out.println("userProfile = " + userProfile);
		}

		response = new GenericResponse();
		userProfile = userProfileHomeExt.trimInput(userProfile);
		if (userProfile == null) {
			resStatus = Status.BAD_REQUEST;
			message = "Empty parameter.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-11");
		} else if (myNullChecker.cni(userProfile.getUserId()) == 0) {
			resStatus = Status.BAD_REQUEST;
			message = "Invalid userId.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-12");
		} else {
			userProfileList = userProfileHomeExt.queryByUserId(userProfile.getUserId());
			if (userProfileList != null && userProfileList.size() > 0) {
				resStatus = Status.NOT_MODIFIED;
				message = "User Details already exists.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-13");
			} else if (userProfileHomeExt.create(userProfile) != null) {
				resStatus = Status.CREATED;
				message = "User Details added successfully.";
				response.setStatus(true);
				response.setMessage(message);
			} else {
				resStatus = Status.INTERNAL_SERVER_ERROR;
				message = "User Details add failed.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-14");
			}
		}

		out.println(message);
		return Response.status(resStatus).entity(response).build();
	}

	@Override
	public Response updateUserProfile(UserProfile userProfile) {
		out.println("*** Calling updateuser @PUT ***");
		try {
			out.println("userProfile in json = " + mapper.writeValueAsString(userProfile));
		} catch (JsonProcessingException e) {
			out.println("userProfile = " + userProfile);
		}

		response = new GenericResponse();
		userProfile = userProfileHomeExt.trimInput(userProfile);
		if (userProfile == null) {
			resStatus = Status.BAD_REQUEST;
			message = "Empty parameter.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-21");
		} else if (myNullChecker.cni(userProfile.getUserId()) == 0) {
			resStatus = Status.BAD_REQUEST;
			message = "Invalid userId.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-22");
		} else {
			userProfileList = userProfileHomeExt.queryByUserId(userProfile.getUserId());
			if (userProfileList == null || userProfileList.size() == 0) {
				resStatus = Status.NOT_FOUND;
				message = "User Details does not exist.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-23");
			} else {
				boolean allDone = true;
				for (UserProfile oldUserProfile : userProfileList) {
					if (userProfile.getFirstName() != null) {
						oldUserProfile.setFirstName(userProfile.getFirstName());
					}
					if (userProfile.getLastName() != null) {
						oldUserProfile.setLastName(userProfile.getLastName());
					}
					if (userProfile.getEmail() != null) {
						oldUserProfile.setEmail(userProfile.getEmail());
					}
					if (userProfile.getMobilePhone() != null) {
						oldUserProfile.setMobilePhone(userProfile.getMobilePhone());
					}

					if (!userProfileHomeExt.update(oldUserProfile)) {
						allDone = false;
					}
				}

				if (allDone) {
					resStatus = Status.OK;
					message = "User Details updated successfully.";
					response.setStatus(true);
					response.setMessage(message);
				} else {
					resStatus = Status.INTERNAL_SERVER_ERROR;
					message = "User Details update failed.";
					response.setStatus(false);
					response.setMessage(message);
					response.setErrorCode("EC-24");
				}
			}
		}

		out.println(message);
		return Response.status(resStatus).entity(response).build();
	}

	@Override
	public Response deleteUserProfile(@QueryParam("userId") Integer userId) {
		out.println("*** Calling deleteuser @DELETE ***");
		out.println("userId = " + userId);

		response = new GenericResponse();
		if (userId == null) {
			resStatus = Status.BAD_REQUEST;
			message = "Empty parameter.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-31");
		} else if (myNullChecker.cni(userId) == 0) {
			resStatus = Status.BAD_REQUEST;
			message = "Invalid userId.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-32");
		} else {
			userProfileList = userProfileHomeExt.queryByUserId(userId);
			if (userProfileList == null || userProfileList.size() == 0) {
				resStatus = Status.NOT_FOUND;
				message = "User Details does not exist.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-33");
			} else {
				boolean allDone = true;
				for (UserProfile userProfile : userProfileList) {
					if (!userProfileHomeExt.delete(userProfile)) {
						allDone = false;
					}
				}

				if (allDone) {
					resStatus = Status.OK;
					message = "User Details deleted successfully.";
					response.setStatus(true);
					response.setMessage(message);
				} else {
					resStatus = Status.INTERNAL_SERVER_ERROR;
					message = "User Details delete failed.";
					response.setStatus(false);
					response.setMessage(message);
					response.setErrorCode("EC-34");
				}
			}
		}

		out.println(message);
		return Response.status(resStatus).entity(response).build();
	}

	@Override
	public Response addResearchData(ResearchData researchData) {
		out.println("*** Calling addResearchData @POST ***");
		try {
			out.println("researchData in json = " + mapper.writeValueAsString(researchData));
		} catch (JsonProcessingException e) {
			out.println("researchData = " + researchData);
		}

		response = new GenericResponse();
		researchData = researchDataHomeExt.trimInput(researchData);
		if (researchData == null) {
			resStatus = Status.BAD_REQUEST;
			message = "Empty parameter.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-41");
		} else {
			// ObjectId for client to save in order for future update
			ObjectId objectId = researchDataHomeExt.create(researchData);
			if (objectId != null) {
				resStatus = Status.CREATED;
				message = objectId.toHexString();
				response.setStatus(true);
				response.setMessage(message);
			} else {
				resStatus = Status.INTERNAL_SERVER_ERROR;
				message = "Data add failed.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-42");
			}
		}

		out.println(message);
		return Response.status(resStatus).entity(response).build();
	}

	@Override
	public Response updateResearchData(ResearchData researchData) {
		out.println("*** Calling updateResearchData @PUT ***");
		try {
			out.println("researchData in json = " + mapper.writeValueAsString(researchData));
		} catch (JsonProcessingException e) {
			out.println("researchData = " + researchData);
		}

		response = new GenericResponse();
		researchData = researchDataHomeExt.trimInput(researchData);
		if (researchData == null) {
			resStatus = Status.BAD_REQUEST;
			message = "Empty parameter.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-51");
		} else {
			researchDataList = researchDataHomeExt.queryByResearchData(researchData);
			if (researchDataList == null || researchDataList.size() == 0) {
				resStatus = Status.NOT_FOUND;
				message = "Data Does Not Exist.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-52");
			} else if (researchDataHomeExt.update(researchData)) {
				resStatus = Status.OK;
				message = "Data updated successfully.";
				response.setStatus(true);
				response.setMessage(message);
			} else {
				resStatus = Status.INTERNAL_SERVER_ERROR;
				message = "Data update failed.";
				response.setStatus(false);
				response.setMessage(message);
				response.setErrorCode("EC-53");
			}
		}

		out.println(message);
		return Response.status(resStatus).entity(response).build();
	}

	@Override
	public List<ResearchData> getResearchDataByStudyId(@QueryParam("studyId") Integer studyId) {
		out.println("*** Calling getResearchDataByStudyId for a given studyId @GET ***");
		out.println("studyId = " + studyId);

		if (studyId == null) {
			message = "Empty parameter.";
			out.println(message);
			return null;
		} else if (myNullChecker.cni(studyId) == 0) {
			message = "Invalid studyId.";
			out.println(message);
			return null;
		}

		researchDataList = researchDataHomeExt.queryByStudyId(studyId);
		if (researchDataList != null) {
			message = "Found " + researchDataList.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}

		out.println(message);
		return researchDataList;
	}

	@Override
	public List<ResearchData> getResearchDataByUserId(@QueryParam("userId") Integer userId) {
		out.println("*** Calling getResearchDataByUserId for a given userId @GET ***");
		out.println("userId = " + userId);

		if (userId == null) {
			message = "Empty parameter.";
			out.println(message);
			return null;
		} else if (myNullChecker.cni(userId) == 0) {
			message = "Invalid userId.";
			out.println(message);
			return null;
		}

		researchDataList = researchDataHomeExt.queryByStudyUserId(userId);
		if (researchDataList != null) {
			message = "Found " + researchDataList.size() + " record/s.";
		} else {
			message = "No records Exist.";
		}

		out.println(message);
		return researchDataList;
	}
}