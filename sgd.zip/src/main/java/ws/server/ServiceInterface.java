package ws.server;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import entity.ResearchData;
import entity.UserProfile;
import ws.authentication.Secured;

/**
 *
 * @author Moroker
 *
 */

@Path("/v1")
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public interface ServiceInterface {

	@GET
	@Path("/")
	@Produces({ MediaType.APPLICATION_JSON })
	Response index();

	@GET
	@Path("/name/{param}")
	@Produces({ MediaType.TEXT_PLAIN })
	Response printMessage(@PathParam("param") String msg);

	@GET
	@Path("/userprofile/list")
	List<UserProfile> listUserProfile();

	@GET
	@Secured
	@Path("/userprofile/get")
	List<UserProfile> getUserProfileByUserId(@QueryParam("userId") Integer userId);

	@POST
	@Secured
	@Path("/userprofile/add")
	Response addUserProfile(UserProfile userProfile);

	@PUT
	@Secured
	@Path("/userprofile/update")
	Response updateUserProfile(UserProfile userProfile);

	@DELETE
	@Secured
	@Path("/userprofile/delete")
	Response deleteUserProfile(@QueryParam("userId") Integer userId);

	@POST
	@Secured
	@Path("/data/add")
	Response addResearchData(ResearchData researchData);

	@PUT
	@Secured
	@Path("/data/update")
	Response updateResearchData(ResearchData researchData);

	@GET
	@Secured
	@Path("/data/getbystudy")
	// @Consumes({ MediaType.APPLICATION_JSON })
	List<ResearchData> getResearchDataByStudyId(@QueryParam("studyId") Integer studyId);

	@GET
	@Secured
	@Path("/data/getbyuser")
	List<ResearchData> getResearchDataByUserId(@QueryParam("userId") Integer userId);
}