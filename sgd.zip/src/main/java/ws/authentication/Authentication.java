package ws.authentication;

import static java.lang.System.out;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.net.URISyntaxException;
import java.security.Key;
import java.time.LocalDateTime;
import java.util.Date;
import javax.ejb.EJB;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import session.UserHomeExt;
import util.MyKeyGenerator;
import util.MyNullChecker;
import util.MyDate;
import ws.model.GenericResponse;

@Path("/v1")
public class Authentication {

	@Context
	private UriInfo uriInfo;

	@EJB
	private UserHomeExt userHomeExt;

	@Inject
	private MyKeyGenerator keyGenerator;

	private Status resStatus;
	private GenericResponse response;

	private String message = "";

	private MyNullChecker myNullChecker = new MyNullChecker();

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/auth")
	public Response authenticateUser(Credentials credentials) throws URISyntaxException {
		out.println("*** Calling auth @POST ***");

		response = new GenericResponse();
		try {
			String username = myNullChecker.cns(credentials.getUsername());
			String password = myNullChecker.cns(credentials.getPassword());

			// Authenticate the user using the credentials provided
			authenticate(username, password);

			// Issue a token for the user
			String token = issueToken(username);

			// Return the token on the response
			resStatus = Status.OK;
			message = token;
			response.setStatus(true);
			response.setMessage(message);
		} catch (Exception e) {
			resStatus = Status.UNAUTHORIZED;
			message = "Authentication failed: invalid username/password.";
			response.setStatus(false);
			response.setMessage(message);
			response.setErrorCode("EC-01");
		}

		out.println(message);
		return Response.status(resStatus).entity(response).build();
		// .location(new URI(uriInfo.getAbsolutePath().toString()))
	}

	private void authenticate(String username, String password) throws Exception {
		// Authenticate against a database, LDAP, file or whatever
		// Throw an Exception if the credentials are invalid
		if (username.equals("") || password.equals("")) {
			throw new Exception();
		}

		if (userHomeExt.queryByUsernameAndPassword(username, password) == null) {
			throw new Exception();
		}
	}

	private String issueToken(String username) {
		// Issue a token (can be a random String persisted to a database or a
		// JWT token)
		// The issued token must be associated to a user
		// Return the issued token
		Key key = keyGenerator.generateKey();
		String jwtToken = Jwts.builder().setSubject(username).setIssuer(uriInfo.getAbsolutePath().toString())
				.setIssuedAt(new Date()).setExpiration(MyDate.toDate(LocalDateTime.now().plusMinutes(60L)))
				.signWith(SignatureAlgorithm.HS512, key).compact();
		return jwtToken;
	}
}