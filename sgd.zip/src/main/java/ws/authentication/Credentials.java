package ws.authentication;

import java.io.Serializable;

import util.MyNullChecker;

public class Credentials implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String username;
	private String password;

	private MyNullChecker myNullChecker = new MyNullChecker();

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = myNullChecker.cns(username).toLowerCase();
	}

	public String getPassword() {
		return password;
	}

	public void setpPassword(String password) {
		this.password = myNullChecker.cns(password);
	}
}