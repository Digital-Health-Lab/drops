package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "participant", propOrder = { "_id", "participantId", "studyId", "age", "gender", "postcode",
		"variableName", "variableValue", "addData", "createdAt", "updatedAt", "deletedAt" })
@XmlRootElement(name = "participant")
public class Participant {

	private ObjectId _id;
	private Integer participantId;
	private Integer studyId;
	private Integer age;
	private String gender;
	private String postcode;
	private String variableName;
	private String variableValue;
	private String addData;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;

	public final String[] fieldNames = { "participantId", "studyId", "age", "gender", "postcode", "variableName",
			"variableValue", "addData", "createdAt", "updatedAt", "deletedAt" };

	public Participant() {
	}

	public Participant(ObjectId _id, Integer participantId, Integer studyId, Integer age, String gender,
			String postcode, String variableName, String variableValue, String addData, Date createdAt, Date updatedAt,
			Date deletedAt) {
		this._id = _id;
		this.participantId = participantId;
		this.studyId = studyId;
		this.age = age;
		this.gender = gender;
		this.postcode = postcode;
		this.variableName = variableName;
		this.variableValue = variableValue;
		this.addData = addData;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Integer participantId) {
		this.participantId = participantId;
	}

	public Integer getStudyId() {
		return studyId;
	}

	public void setStudyId(Integer studyId) {
		this.studyId = studyId;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public String getVariableValue() {
		return variableValue;
	}

	public void setVariableValue(String variableValue) {
		this.variableValue = variableValue;
	}

	public String getAddData() {
		return addData;
	}

	public void setAddData(String addData) {
		this.addData = addData;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
}