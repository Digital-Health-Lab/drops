package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "source", propOrder = { "_id", "sourceId", "name", "model", "version", "wearType", "wearPosition",
		"wearPositionOther", "variableName", "variableValue", "addData", "createdAt", "updatedAt", "deletedAt" })
@XmlRootElement(name = "source")
public class Source {

	private ObjectId _id;
	private Integer sourceId;
	private String name;
	private String model;
	private String version;
	private String wearType;
	private String wearPosition;
	private String wearPositionOther;
	private String variableName;
	private String variableValue;
	private String addData;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;

	public final String[] fieldNames = { "sourceId", "name", "model", "version", "wearType", "wearPosition",
			"wearPositionOther", "variableName", "variableValue", "addData", "createdAt", "updatedAt", "deletedAt" };

	public Source() {
	}

	public Source(ObjectId _id, Integer sourceId, String name, String model, String version, String wearType,
			String wearPosition, String wearPositionOther, String variableName, String variableValue, String addData,
			Date createdAt, Date updatedAt, Date deletedAt) {
		this._id = _id;
		this.sourceId = sourceId;
		this.name = name;
		this.model = model;
		this.version = version;
		this.wearType = wearType;
		this.wearPosition = wearPosition;
		this.wearPositionOther = wearPositionOther;
		this.variableName = variableName;
		this.variableValue = variableValue;
		this.addData = addData;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getWearType() {
		return wearType;
	}

	public void setWearType(String wearType) {
		this.wearType = wearType;
	}

	public String getWearPosition() {
		return wearPosition;
	}

	public void setWearPosition(String wearPosition) {
		this.wearPosition = wearPosition;
	}

	public String getWearPositionOther() {
		return wearPositionOther;
	}

	public void setWearPositionOther(String wearPositionOther) {
		this.wearPositionOther = wearPositionOther;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public String getVariableValue() {
		return variableValue;
	}

	public void setVariableValue(String variableValue) {
		this.variableValue = variableValue;
	}

	public String getAddData() {
		return addData;
	}

	public void setAddData(String addData) {
		this.addData = addData;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
}