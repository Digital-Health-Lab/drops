package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

import com.fasterxml.jackson.annotation.JsonFormat;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stepCount", propOrder = { "_id", "participantId", "sourceId", "measuredAt", "duration", "steps",
		"xAxis", "yAxis", "zAxis", "variableName", "variableValue", "addData", "createdAt", "updatedAt", "deletedAt" })
@XmlRootElement(name = "stepCount")
public class StepCount {

	private ObjectId _id;
	private Integer participantId;
	private Integer sourceId;
	@JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss")
	private Date measuredAt;
	private Integer duration;
	private Integer steps;
	private Double xAxis;
	private Double yAxis;
	private Double zAxis;
	private String variableName;
	private String variableValue;
	private String addData;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;

	public final String[] fieldNames = { "participantId", "sourceId", "measuredAt", "duration", "steps", "xAxis",
			"yAxis", "zAxis", "variableName", "variableValue", "addData", "createdAt", "updatedAt", "deletedAt" };

	public StepCount() {
	}

	public StepCount(ObjectId _id, Integer participantId, Integer sourceId, Date measuredAt, Integer duration,
			Integer steps, Double xAxis, Double yAxis, Double zAxis, String variableName, String variableValue,
			String addData, Date createdAt, Date updatedAt, Date deletedAt) {
		this._id = _id;
		this.participantId = participantId;
		this.sourceId = sourceId;
		this.measuredAt = measuredAt;
		this.duration = duration;
		this.steps = steps;
		this.xAxis = xAxis;
		this.yAxis = yAxis;
		this.zAxis = zAxis;
		this.variableName = variableName;
		this.variableValue = variableValue;
		this.addData = addData;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Integer participantId) {
		this.participantId = participantId;
	}

	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	public Date getMeasuredAt() {
		return measuredAt;
	}

	public void setMeasuredAt(Date measuredAt) {
		this.measuredAt = measuredAt;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getSteps() {
		return steps;
	}

	public void setSteps(Integer steps) {
		this.steps = steps;
	}

	public Double getXAxis() {
		return xAxis;
	}

	public void setXAxis(Double xAxis) {
		this.xAxis = xAxis;
	}

	public Double getYAxis() {
		return yAxis;
	}

	public void setYAxis(Double yAxis) {
		this.yAxis = yAxis;
	}

	public Double getZAxis() {
		return zAxis;
	}

	public void setZAxis(Double zAxis) {
		this.zAxis = zAxis;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public String getVariableValue() {
		return variableValue;
	}

	public void setVariableValue(String variableValue) {
		this.variableValue = variableValue;
	}

	public String getAddData() {
		return addData;
	}

	public void setAddData(String addData) {
		this.addData = addData;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
}