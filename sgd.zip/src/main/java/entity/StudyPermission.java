package entity;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.bson.types.ObjectId;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "studyPermission", propOrder = { "_id", "studyPermissionId", "studyId", "userId", "permissionStatus",
		"createdAt", "updatedAt", "deletedAt" })
@XmlRootElement(name = "studyPermission")
public class StudyPermission {

	private ObjectId _id;
	private Integer studyPermissionId;
	private Integer studyId;
	private Integer userId;
	private String permissionStatus;
	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;

	public final String[] fieldNames = { "studyPermissionId", "studyId", "userId", "permissionStatus", "createdAt",
			"updatedAt", "deletedAt" };

	public StudyPermission() {
	}

	public StudyPermission(ObjectId _id, Integer studyPermissionId, Integer studyId, Integer userId,
			String permissionStatus, Date createdAt, Date updatedAt, Date deletedAt) {
		this._id = _id;
		this.studyPermissionId = studyPermissionId;
		this.studyId = studyId;
		this.userId = userId;
		this.permissionStatus = permissionStatus;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.deletedAt = deletedAt;
	}

	public ObjectId get_id() {
		return _id;
	}

	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	public Integer getStudyPermissionId() {
		return studyPermissionId;
	}

	public void setStudyPermissionId(Integer studyPermissionId) {
		this.studyPermissionId = studyPermissionId;
	}

	public Integer getStudyId() {
		return studyId;
	}

	public void setStudyId(Integer studyId) {
		this.studyId = studyId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getPermissionStatus() {
		return permissionStatus;
	}

	public void setPermissionStatus(String permissionStatus) {
		this.permissionStatus = permissionStatus;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
}