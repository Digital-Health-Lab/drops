package constant;

/**
 * @author Moroker
 *
 */
public class Constants {

	public static final String LOGIN_FAILURE = "loginFailure";
	public static final String LOGIN_SUCCESS = "loginSuccess";
	public static final String LOGOUT = "logout";

	public static final String PUBLIC_HOME_PAGE = "/index.xhtml";

	public static final String HOST_NAME_LOCAL = "localhost";
	public static final int DB_PORT = 27017;
	public static final String DATABASE = "ands";
	public static final String USERNAME = "yang";
	public static final char[] PASSWORD = "yangNectar".toCharArray();
}
