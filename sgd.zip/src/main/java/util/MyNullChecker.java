/*
 * YNullChecker.java
 *
 * Created on 23 July 2014
 * Check whether an object is null
 */

/**
 * @author Moroker
 * @version 0.1
 */

package util;

public class MyNullChecker {

	public MyNullChecker() {
	}

	/**
	 * Return an empty String value if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @return the String value of the parsed object, or an empty String value
	 */
	public String cns(Object theObject) {
		return cns(theObject, "");
	}

	/**
	 * Return an default String value if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @param theDefault
	 *            - a default return value if the parsed object is null
	 * @return the String value of the parsed object, or a default String value
	 */
	public String cns(Object theObject, String theDefault) {
		if (theObject != null && !theObject.toString().trim().equals("")
				&& !theObject.toString().trim().toLowerCase().equals("null")) {
			theDefault = theObject.toString().trim();
		}

		// If theObject is non String instance, return theDefault.
		return theDefault;
	}

	/**
	 * Return an Integer value of 0 if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @return the Integer value of the parsed object, or an Integer value of 0
	 */
	public Integer cni(Object theObject) {
		return cni(theObject, new Integer(0));
	}

	/**
	 * Return a default Integer value if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @param theDefault
	 *            - a default return value if the parsed object is null
	 * @return the Integer value of the parsed object, or a default Integer
	 *         value
	 */
	public Integer cni(Object theObject, Integer theDefault) {
		if (theObject != null && theObject instanceof Integer) {
			theDefault = (Integer) theObject;
		} else if (theObject instanceof String) {
			try {
				theDefault = new Integer(theObject.toString().replaceAll(",", ""));
			} catch (Exception e) {
			}
		}

		// If theObject is non String/Integer instance, return theDefault.
		return theDefault;
	}

	/**
	 * Return an Long value of 0 if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @return the Long value of the parsed object, or an Long value of 0
	 */
	public Long cnl(Object theObject) {
		return cnl(theObject, new Long(0));
	}

	/**
	 * Return a default Long value if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @param theDefault
	 *            - a default return value if the parsed object is null
	 * @return the Long value of the parsed object, or a default Long value
	 */
	public Long cnl(Object theObject, Long theDefault) {
		if (theObject != null && theObject instanceof Long) {
			theDefault = (Long) theObject;
		} else if (theObject instanceof String) {
			try {
				theDefault = new Long(theObject.toString());
			} catch (Exception e) {
			}
		}

		// If theObject is non String/Long instance, return theDefault.
		return theDefault;
	}

	/**
	 * Return an Float value of 0 if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @return the Float value of the parsed object, or an Float value of 0
	 */
	public Float cnf(Object theObject) {
		return cnf(theObject, new Float(0));
	}

	/**
	 * Return a default Float value if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @param theDefault
	 *            - a default return value if the parsed object is null
	 * @return the Float value of the parsed object, or a default Float value
	 */
	public Float cnf(Object theObject, Float theDefault) {
		if (theObject != null && theObject instanceof Float) {
			theDefault = (Float) theObject;
		} else if (theObject instanceof String) {
			try {
				theDefault = new Float(theObject.toString().replaceAll(",", ""));
			} catch (Exception e) {
			}
		}

		// If theObject is non String/Float instance, return theDefault.
		return theDefault;
	}

	/**
	 * Return an Double value of 0 if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @return the Double value of the parsed object, or an Double value of 0
	 */
	public Double cnd(Object theObject) {
		return cnd(theObject, new Double(0));
	}

	/**
	 * Return a default Double value if the parsed object is null.
	 * 
	 * @param theObject
	 *            - an object to be checked
	 * @param theDefault
	 *            - a default return value if the parsed object is null
	 * @return the Double value of the parsed object, or a default Double value
	 */
	public Double cnd(Object theObject, Double theDefault) {
		if (theObject != null && theObject instanceof Double) {
			theDefault = (Double) theObject;
		} else if (theObject instanceof String) {
			try {
				theDefault = new Double(theObject.toString().replaceAll(",", ""));
			} catch (Exception e) {
			}
		}

		// If theObject is non String/Double instance, return theDefault.
		return theDefault;
	}
}