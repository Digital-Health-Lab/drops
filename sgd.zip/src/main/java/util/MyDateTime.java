/*
 * YDateTime.java
 *
 * Created on 23 July 2014
 */

/**
 * @author Moroker
 * @version 0.1
 */

package util;

import java.util.Date;
import java.util.Locale;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Vector;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class MyDateTime {

	private SimpleDateFormat sdf = null;
	private GregorianCalendar gc = null;

	public MyDateTime() {
	}

	/**
	 * Tell whether the input date is valid.
	 * 
	 * @param theDate
	 *            - the string of date
	 * @param theDateFormat
	 *            - the specified Date Format
	 * @return true if it is valid, otherwise, false
	 * @throws Exception
	 */
	public boolean isThisDateValid(String theDate, String theDateFormat) {
		if (theDate == null) {
			return false;
		}

		try {
			getDateFromString(theDate, theDateFormat);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/**
	 * Get the current Date and Time.
	 * 
	 * @return the Date of current date and time
	 */
	public Date getCurrentDateTime() {
		gc = new GregorianCalendar();
		return gc.getTime();
	}

	/**
	 * Convert a string of date into a Date of date.
	 * 
	 * @param theDate
	 *            - the string of date
	 * @param theDateFormat
	 *            - the specified Date Format
	 * @return the Date of date
	 */
	public Date getDateFromString(String theDate, String theDateFormat)
			throws Exception {
		Date returnDate = null;

		SimpleDateFormat sdf = new SimpleDateFormat(theDateFormat);
		sdf.setLenient(false);

		try {
			returnDate = sdf.parse(theDate);
		} catch (ParseException pe) {
			throw new Exception(
					"Exception - (YDateTime) getDateFromString(String theDate): Input parameter: "
							+ theDate + "\n" + pe);
			// gc = new GregorianCalendar(100, 0, 1); // 01/01/2000
			// returnDate = gc.getTime();
			// The other way.
			// Calendar c = Calendar.getInstance();
			// c.getInstance().set(100, 0, 1);
			// returnDate = c.getTime();

		}
		return returnDate;
	}

	/**
	 * Get the String of current Date and Time in general SQL
	 * format(CONVERT(DATETIME, '2007-11-26 00:00:00', 102)).
	 */
	public String getSQLQueryDateTime() throws Exception {
		return getSQLQueryDateTime(getCurrentDateTime());
	}

	/**
	 * Get the String of specified Date and Time in general SQL
	 * format(CONVERT(DATETIME, '2007-11-26 00:00:00', 102)).
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of SQL Date and Time
	 */
	public String getSQLQueryDateTime(Date theDate) throws Exception {
		return "CONVERT(DATETIME, '"
				+ formatDate(theDate, "yyyy-MM-dd hh:mm:ss") + "', 102)";
	}

	/**
	 * Get the String of current Date and Time in SQL format(US format).
	 * Purpose: store the current Date into DB or do the date compare in SQL
	 * query.
	 */
	public String getSQLDateTime() throws Exception {
		return getSQLDateTime(getCurrentDateTime());
	}

	/**
	 * Get the String of specified Date and Time in SQL format(US format).
	 * Purpose: store the specified Date into DB or do the date compare in SQL
	 * query.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of SQL Date and Time
	 */
	public String getSQLDateTime(Date theDate) throws Exception {
		return formatDate(theDate, "MM/dd/yyyy hh:mm:ss a");
	}

	/**
	 * Get the String of current Date and Time in Australian format.
	 */
	public String getAusDateTime() throws Exception {
		return getAusDateTime(getCurrentDateTime());
	}

	/**
	 * Get the String of specified Date and Time in Australian format.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of Australian Date and Time
	 */
	public String getAusDateTime(Date theDate) throws Exception {
		return formatDate(theDate, "dd/MM/yyyy hh:mm:ss a");
	}

	/**
	 * Get the String of current Date in SQL format(US format).
	 */
	public String getSQLDate() throws Exception {
		return getSQLDate(getCurrentDateTime());
	}

	/**
	 * Get the String of specified Date in SQL format(US format).
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of SQL Date
	 */
	public String getSQLDate(Date theDate) throws Exception {
		return formatDate(theDate, "MM/dd/yyyy");
	}

	/**
	 * Get the String of current Date in Australian format. Purpose: get the
	 * display format of the date(dd/MM/yyyy).
	 */
	public String getAusDate() throws Exception {
		return getAusDate(getCurrentDateTime());
	}

	/**
	 * Get the String of specified Date in Australian format. Purpose: get the
	 * display format of the date(dd/MM/yyyy).
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of Australian Date
	 */
	public String getAusDate(Date theDate) throws Exception {
		return formatDate(theDate, "dd/MM/yyyy");
	}

	/**
	 * Get the String of specified Date in format (Thu, 1 Jan 2009).
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of Date
	 */
	public String getLongDate(Date theDate) throws Exception {
		return formatDate(theDate, "EEE, d MMM yyyy");
	}

	/**
	 * Get the String of specified Date in Customised format.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param theDateFormat
	 *            - the specified Date Format
	 * @return the String of Date in the customised date format
	 */
	public String formatDate(Date theDate, String theDateFormat)
			throws Exception {
		String returnDate = "";
		try {
			sdf = new SimpleDateFormat(theDateFormat, new Locale("en", "AUS"));
			returnDate = sdf.format(theDate);
		} catch (Exception e) {
			throw new Exception(
					"Exception - (YDateTime) formatDate(Date theDate, String theDateFormat): Input parameter: "
							+ theDate + "\n" + e);
		}
		return returnDate;
	}

	/**
	 * Convert the date between Aus and SQL. Purpose: store the sting date into
	 * DB.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the String of Date in the other format (SQL or Aus)
	 */
	public String ConvertBetweenAusAndSQL(String theDate) {
		String[] splitDate = theDate.split("/", 3);
		if (splitDate.length == 3) {
			theDate = splitDate[1] + "/" + splitDate[0] + "/" + splitDate[2];
		} else {
			System.out
					.println("Error - (YDateTime) ConvertBetweenAusAndSQL(String theDate): Input parameter: "
							+ theDate);
		}
		return theDate;
	}

	/**
	 * Get the year of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the year
	 */
	public int getYear(Date theDate) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		return gc.get(Calendar.YEAR);
	}

	/**
	 * Get the month of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the month
	 */
	public int getMonth(Date theDate) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		return gc.get(Calendar.MONTH) + 1;
	}

	/**
	 * Get the day of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the day
	 */
	public int getDay(Date theDate) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		return gc.get(Calendar.DATE);
	}

	/**
	 * Convert integer representation of a week day into string. ie: 1 will
	 * return Sunday...
	 * 
	 * @param theDay
	 *            - numeric representation of week day to convert
	 * @param isShort
	 *            - whether to return the full or abbreviated month
	 * @return the week day string
	 */
	public String getDayAsText(int theDay, boolean isShort) {
		String returnString = "";
		switch (theDay) {
		case Calendar.SUNDAY:
			returnString = "Sunday";
			break;
		case Calendar.MONDAY:
			returnString = "Monday";
			break;
		case Calendar.TUESDAY:
			returnString = "Tuesday";
			break;
		case Calendar.WEDNESDAY:
			returnString = "Wednesday";
			break;
		case Calendar.THURSDAY:
			returnString = "Thursday";
			break;
		case Calendar.FRIDAY:
			returnString = "Friday";
			break;
		case Calendar.SATURDAY:
			returnString = "Saturday";
			break;
		default:
			returnString = "Unknown";
			break;
		}
		if (isShort) {
			returnString = returnString.substring(0, 3);
		}
		return returnString;
	}

	/**
	 * Convert integer representation of a month into string. ie: 0 will return
	 * January...
	 * 
	 * @param theMonth
	 *            - numeric representation of month to convert
	 * @param isShort
	 *            - whether to return the full or abbreviated month
	 * @return the month string
	 */
	public String getMonthAsText(int theMonth, boolean isShort) {
		String returnString = "";
		switch (theMonth) {
		case 0:
			returnString = "January";
			break;
		case 1:
			returnString = "February";
			break;
		case 2:
			returnString = "March";
			break;
		case 3:
			returnString = "April";
			break;
		case 4:
			returnString = "May";
			break;
		case 5:
			returnString = "June";
			break;
		case 6:
			returnString = "July";
			break;
		case 7:
			returnString = "August";
			break;
		case 8:
			returnString = "September";
			break;
		case 9:
			returnString = "October";
			break;
		case 10:
			returnString = "November";
			break;
		case 11:
			returnString = "December";
			break;
		default:
			returnString = "Unknown";
			break;
		}
		if (isShort) {
			returnString = returnString.substring(0, 3);
		}
		return returnString;
	}

	/**
	 * Get weekday Date in the week of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param theWeekday
	 *            - the specified weekday
	 * @return the weekday Date
	 */
	public Date getWeekday(Date theDate, String theWeekday) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		if (theWeekday.equals("Sunday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		} else if (theWeekday.equals("Monday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		} else if (theWeekday.equals("Tuesday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY);
		} else if (theWeekday.equals("Wednesday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.WEDNESDAY);
		} else if (theWeekday.equals("Thursday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		} else if (theWeekday.equals("Friday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY);
		} else if (theWeekday.equals("Saturday")) {
			gc.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		} else {
			System.out
					.println("Error - (YDateTime) getWeekday(Date theDate, String theWeekday): Input parameter: "
							+ theWeekday);
		}
		return gc.getTime();
	}

	/**
	 * Get the first day's Date in the month of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the first day's Date
	 */
	public Date getMonthBegin(Date theDate) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		gc.set(Calendar.DAY_OF_MONTH, 1);
		return gc.getTime();
	}

	/**
	 * Get the last day's Date in the month of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the last day's Date
	 */
	public Date getMonthEnd(Date theDate) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		gc.set(Calendar.DAY_OF_MONTH, gc.getActualMaximum(Calendar.DATE));
		return gc.getTime();
	}

	/**
	 * Get the number of days in the month of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @return the number of days
	 */
	public int getMonthDaysCount(Date theDate) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		return gc.getActualMaximum(Calendar.DATE);
	}

	/**
	 * Get a Vector of the total dates in the month of the specified Date.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param theDateFormat
	 *            - the specified Date Format
	 * @return the Vector of the total dates
	 */
	public Vector<String> getTotalMonth(Date theDate, String theDateFormat)
			throws Exception {
		Vector<String> returnVector = new Vector<String>();
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		int intMonthDaysCount = gc.getActualMaximum(Calendar.DATE);
		for (int i = 1; i <= intMonthDaysCount; i++) {
			gc.set(Calendar.DAY_OF_MONTH, i);
			returnVector.add(formatDate(gc.getTime(), theDateFormat));
		}
		return returnVector;
	}

	/**
	 * Get the Date specified Date after changing an offset.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param offset
	 *            - the days after or before the specified Date
	 * @return the Date after changing
	 */
	public Date changeDay(Date theDate, int offset) {
		return changeFromOffset(theDate, offset, Calendar.DAY_OF_YEAR);
	}

	/**
	 * Get the Date specified Date after changing an offset.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param offset
	 *            - the hours after or before the specified Date time
	 * @return the Date after changing
	 */
	public Date changeHour(Date theDate, int offset) {
		return changeFromOffset(theDate, offset, Calendar.HOUR_OF_DAY);
	}

	/**
	 * Get the Date specified Date after changing an offset.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param offset
	 *            - the minutes after or before the specified Date time
	 * @return the Date after changing
	 */
	public Date changeMinute(Date theDate, int offset) {
		return changeFromOffset(theDate, offset, Calendar.MINUTE);
	}

	/**
	 * Get the Date specified Date after changing an offset.
	 * 
	 * @param theDate
	 *            - the specified Date
	 * @param offset
	 *            - the offset after or before the specified Date time
	 * @param fieldType
	 *            - the Field number, eg: Calendar.HOUR_OF_DAY
	 * @return the Date after changing
	 */
	public Date changeFromOffset(Date theDate, int offset, int fieldType) {
		gc = new GregorianCalendar();
		gc.setTime(theDate);
		gc.set(fieldType, (gc.get(fieldType) + offset));
		return gc.getTime();
	}

	/**
	 * Get the difference between two specified Dates.
	 * 
	 * @param theDate1
	 *            - the specified Date1
	 * @param theDate2
	 *            - the specified Date2
	 * @return positive if Date2 is after Date1, otherwise, negative
	 */
	public int getDiffOfDates(Date theDate1, Date theDate2) {
		return (int) ((theDate2.getTime() - theDate1.getTime()) / (1000 * 60 * 60 * 24));
	}

	/**
	 * Get the difference between two specified Dates in minutes.
	 * 
	 * @param theDate1
	 *            - the specified Date1
	 * @param theDate2
	 *            - the specified Date2
	 * @return positive if Date2 is after Date1, otherwise, negative
	 */
	public int getDiffOfDatesInMinutes(Date theDate1, Date theDate2) {
		return (int) ((theDate2.getTime() - theDate1.getTime()) / (1000 * 60));
	}

	/**
	 * Tell whether the two specified Dates are in the same week.
	 * 
	 * @param theDate1
	 *            - the specified Date1
	 * @param theDate2
	 *            - the specified Date2
	 * @return true if they are in the same week, otherwise, false
	 */
	public boolean isInTheSameWeek(Date theDate1, Date theDate2) {
		long diff = getWeekday(theDate1, "Monday").getTime()
				- getWeekday(theDate2, "Monday").getTime();
		return Math.abs(diff) < 1000 * 60 * 60 * 24;
	}

	/**
	 * Tell whether the specified year is a leap year.
	 * 
	 * @param theYear
	 *            - the specified year
	 * @return true if it is, otherwise, false
	 */
	public boolean isLeapYear(int theYear) {
		gc = new GregorianCalendar(theYear, 2, 1);
		return gc.get(Calendar.DAY_OF_YEAR) == 366;
		// The other way.
		/*
		 * gc.add(Calendar.DATE, -1); return gc.get(Calendar.DAY_OF_MONTH) ==
		 * 29;
		 */
	}
}
