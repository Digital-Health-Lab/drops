package util;

import static java.lang.System.out;

import java.util.LinkedHashMap;
import java.util.Map;

public class MyDocument {

	/** Convert the document to map */
	public static Map<String, String> documentToMap(String str) {
		str = str.substring(1, str.length() - 1);
		String strArr[] = str.split(",");
		Map<String, String> map = new LinkedHashMap<String, String>();
		for (int i = 1; i < strArr.length; i++) {
			String keyValue[] = strArr[i].split(":");
			String key = purifyKeyValueString(keyValue[0]);
			String value = "";
			if (!strArr[i].contains("$date")) {
				value = purifyKeyValueString(keyValue[1]);
			} else {
				value = purifyKeyValueString(keyValue[2]);
			}

			map.put(key, value);
			out.println(key + " : " + value);
		}

		return map;
	}

	private static String purifyKeyValueString(String str) {
		if (str != null) {
			str = removeOuterChar(str, "\"");
			str = removeOuterChar(str, "{");
			str = removeOuterChar(str, "}");
		}

		return str;
	}

	private static String removeOuterChar(String str, String c) {
		if (str != null && c != null && c.length() == 1) {
			str = str.trim();
			if (str.indexOf(c) == 0) {
				str = str.substring(1, str.length() - 1).trim();
			}
			if (str.indexOf(c) == str.length() - 1) {
				str = str.substring(0, str.length() - 2).trim();
			}
		}

		return str;
	}
}