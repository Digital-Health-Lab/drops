package util;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class MyDate {

	/** Convert the server time to local time */
	public static String serverTimeToLocalTime(String longNumberStr) {
		Instant utcInstant = new Date(Long.parseLong(longNumberStr)).toInstant();
		ZonedDateTime there = ZonedDateTime.ofInstant(utcInstant, ZoneId.of("UTC"));
		LocalDateTime here = there.withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

		return format.format(here);
	}

	public static Date toDate(LocalDateTime localDateTime) {
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}
}