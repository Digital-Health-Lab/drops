package client;

import static java.lang.System.out;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import javax.naming.NamingException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import org.apache.commons.io.IOUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;
import org.jboss.resteasy.client.jaxrs.engines.ApacheHttpClient4Engine;
import org.junit.Before;
import org.junit.Test;

import entity.UserProfile;
import ws.server.ServiceInterface;

public class RestEasyClientLiveTest {

	public static final UriBuilder FULL_PATH = UriBuilder.fromPath("http://127.0.0.1:8080/sgd/api");
	UserProfile morokerUserProfile = null;
	UserProfile lanyingUserProfile = null;
	ObjectMapper jsonMapper = null;

	@Before
	public void setup() throws ClassNotFoundException, IllegalAccessException, InstantiationException, NamingException {
		jsonMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		jsonMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		final SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.ENGLISH);
		jsonMapper.setDateFormat(sdf);

		try (InputStream inputStream = new RestEasyClientLiveTest().getClass()
				.getResourceAsStream("/userprofile/moroker.json")) {
			final String userprofileAsString = String.format(IOUtils.toString(inputStream, StandardCharsets.UTF_8));
			morokerUserProfile = jsonMapper.readValue(userprofileAsString, UserProfile.class);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Test is going to die ...", e);
		}

		try (InputStream inputStream = new RestEasyClientLiveTest().getClass()
				.getResourceAsStream("/userprofile/lanying.json")) {
			final String userprofileAsString = String.format(IOUtils.toString(inputStream, StandardCharsets.UTF_8));
			lanyingUserProfile = jsonMapper.readValue(userprofileAsString, UserProfile.class);
		} catch (final Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Test is going to die ...", e);
		}
	}

	@Test
	public void testListUserProfile() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserProfile(morokerUserProfile);
		response.close();
		response = proxy.addUserProfile(lanyingUserProfile);
		response.close();

		final List<UserProfile> userProfile = proxy.listUserProfile();
		out.println("testListUserProfile - " + userProfile);
	}

	@Test
	public void testGetUserProfileByUserId() {
		final Integer userId = 8;

		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		final Response response = proxy.addUserProfile(morokerUserProfile);
		response.close();

		final UserProfile userProfile = proxy.getUserProfileByUserId(userId);
		out.println("testGetUserProfileByUserId - " + userProfile);
	}

	@Test
	public void testAddUserProfile() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserProfile(morokerUserProfile);
		response.close();
		response = proxy.addUserProfile(lanyingUserProfile);

		if (response.getStatus() != Response.Status.CREATED.getStatusCode()) {
			out.println("testAddUserProfile - Failed : HTTP error code : " + response.getStatus());
		}

		response.close();
		out.println("testAddUserProfile - Response Code: " + response.getStatus());
	}

	@Test
	public void testAddUserProfileMultiConnection() {
		final PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
		final CloseableHttpClient httpClient = HttpClients.custom().setConnectionManager(cm).build();
		final ApacheHttpClient4Engine engine = new ApacheHttpClient4Engine(httpClient);
		final ResteasyClient client = new ResteasyClientBuilder().httpEngine(engine).build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		final Response morokerResponse = proxy.addUserProfile(morokerUserProfile);
		final Response lanyingResponse = proxy.addUserProfile(lanyingUserProfile);

		if (morokerResponse.getStatus() != Response.Status.CREATED.getStatusCode()) {
			out.println("testAddUserProfileMultiConnection - moroker UserProfile creation Failed : HTTP error code : "
					+ morokerResponse.getStatus());
		}
		if (lanyingResponse.getStatus() != Response.Status.CREATED.getStatusCode()) {
			out.println("testAddUserProfileMultiConnection - lanying UserProfile creation Failed : HTTP error code : "
					+ lanyingResponse.getStatus());
		}

		morokerResponse.close();
		lanyingResponse.close();
		cm.close();
		out.println("testAddUserProfileMultiConnection - Response Code: " + morokerResponse.getStatus());
	}

	@Test
	public void testDeleteUserProfile() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserProfile(lanyingUserProfile);
		response.close();
		response = proxy.deleteUserProfile(lanyingUserProfile.getUserId());

		if (response.getStatus() != Response.Status.OK.getStatusCode()) {
			out.println(response.readEntity(String.class));
			throw new RuntimeException("testDeleteUserProfile - Failed : HTTP error code : " + response.getStatus());
		}

		response.close();
		out.println("testDeleteUserProfile - Response Code: " + response.getStatus());
	}

	@Test
	public void testUpdateUserProfile() {
		final ResteasyClient client = new ResteasyClientBuilder().build();
		final ResteasyWebTarget target = client.target(FULL_PATH);
		final ServiceInterface proxy = target.proxy(ServiceInterface.class);

		Response response = proxy.addUserProfile(lanyingUserProfile);
		response.close();
		lanyingUserProfile.setMobilePhone("0416174580");
		response = proxy.updateUserProfile(lanyingUserProfile);

		if (response.getStatus() != Response.Status.OK.getStatusCode()) {
			out.println("testUpdateUserProfile - Failed : HTTP error code : " + response.getStatus());
		}

		response.close();
		out.println("testUpdateUserProfile - Response Code: " + response.getStatus());
	}
}